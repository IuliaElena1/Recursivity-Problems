/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.common.menus;

import java.util.ArrayList;
import java.util.List;

import com.ssn.common.keyboard.Keyboard;

public class Menu extends MenuItem {
  private final List<MenuItem> menus = new ArrayList<MenuItem>();
  private MenuItem backMenu;

  public Menu(String option, String name) {
    super(option, name);
  }

  @Override
  protected void run() {
    Keyboard kb = new Keyboard();

    while (true) {
      showMenu();
      String opt = kb.readLineWithMessage("Option: ");

      MenuItem menuChosen = getMenuItemByOption(opt);
      if (menuChosen == null) {
        System.out.println("Invalid option! Try again.");
        continue;
      }
      if (menuChosen == backMenu) {
        break;
      } else {
        menuChosen.doAction();
      }
    }
  }

  private MenuItem getMenuItemByOption(String opt) {
    MenuItem menuChosen = null;
    for (MenuItem mi : menus) {
      if (mi.getOption().equals(opt)) {
        menuChosen = mi;
        break;
      }
    }
    return menuChosen;
  }

  private void showMenu() {
    System.out.println("----" + super.getName() + "----");
    for (MenuItem m : menus) {
      System.out.println(m);
    }
  }

  public void addMenuItem(MenuItem m) {
    menus.add(m);
  }

  public void setBackOption(MenuItem m) {
    this.backMenu = m;
  }
}
