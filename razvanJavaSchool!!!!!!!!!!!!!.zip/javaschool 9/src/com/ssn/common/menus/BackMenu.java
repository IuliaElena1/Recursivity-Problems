/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.common.menus;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class BackMenu extends MenuItem {

  public BackMenu(String option, String name) {
    super(option, name);
  }

  @Override
  protected void run() {
    //
  }

}
