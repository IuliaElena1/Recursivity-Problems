/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.common.menus;

public abstract class MenuItem {
  private final String option;
  private final String name;

  public MenuItem(String option, String name) {
    this.option = option;
    this.name = name;
  }

  protected abstract void run();

  public String getOption() {
    return option;
  }

  @Override
  public String toString() {
    return "" + option + ". " + name;
  }

  public String getName() {
    return name;
  }

  public void doAction() {
    try {
      run();
    } catch (RuntimeException e) {
      System.out.println(e.getMessage());
    }
  }

}
