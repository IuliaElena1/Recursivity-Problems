
package com.ssn.common.keyboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Keyboard {
  BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

  public String readLine() {
    try {
      return bufferedReader.readLine();
    } catch (IOException e) {
      System.out.println("Invalid input.");
      return null;
    }
  }

  public String readLineWithMessage(String message) {
    System.out.print(message);
    try {
      return bufferedReader.readLine();
    } catch (IOException e) {
      System.out.println("Invalid input.");
      return null;
    }
  }

  public String readLineWithConfirmation(String message, String[] options) {
    String line = "";
    while (true) {
      try {
        System.out.print(message);
        line = bufferedReader.readLine();
        for (String string : options) {
          if (line.equalsIgnoreCase(string)) {
            return string;
          }
        }
        System.out.println("invalid input");
        //   return line;

      } catch (IOException e) {
        System.out.println("Invalid input");
        return line;
      }
    }
  }

  public int readInt() {
    try {
      return Integer.parseInt(readLine());
    } catch (NumberFormatException e) {
      System.out.println("Invalid number.");
      return 0;
    }
  }

  public double readDouble() {
    try {
      return Double.parseDouble(readLine());
    } catch (NumberFormatException e) {
      System.out.println("Invalid number.");
      return 0;
    }
  }
}
