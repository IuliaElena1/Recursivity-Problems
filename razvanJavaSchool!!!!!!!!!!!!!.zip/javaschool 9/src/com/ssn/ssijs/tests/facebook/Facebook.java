/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.facebook;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Facebook {
  private List<Person> persons = new ArrayList<>();

  public void add(String name) {
    Person person = getPersonByName(name);
    if (person == null) {
      person = new Person(name);
      persons.add(person);
    }
  }

  private Person getPersonByName(String name) {
    for (Person p : persons) {
      if (p.hasName(name)) {
        return p;
      }
    }
    return null;
  }

  public void addRelation(String person1, String person2) {
    Person p1 = getPersonByName(person1);
    Person p2 = getPersonByName(person2);
    p1.addFriend(p2);
    p2.addFriend(p1);
  }

  private int countSolutions = 0;
  private List<Route> allSolutions = new ArrayList<>();

  private void search(Person current, Person stop, Route solution) {
    solution.show();
    System.out.println(" (" + current + ")");

    // evitam buclele
    if (solution.contains(current)) {
      return;
    }

    // adaugam nodul curent la drumul curent
    solution.add(current);

    // daca am ajuns la solutie 
    if (current.equals(stop)) {
      // am ajuns la solutie
      //solution.show();
      //System.out.println();
      countSolutions++;
      allSolutions.add(solution.clone());
    } else {
      List<Person> friends = current.getFriends();
      for (Person p : friends) {
        search(p, stop, solution);
      }
    }

    // foarte important stergem punctul adaugat cu add
    solution.removeLast();

  }

  public List<Route> showPath(String c, String s) {
    Person current = getPersonByName(c);
    Person stop = getPersonByName(s);

    Route currentSolution = new Route();

    countSolutions = 0;
    allSolutions.clear();

    search(current, stop, currentSolution);

    System.out.println(countSolutions);
    return allSolutions;
  }
}
