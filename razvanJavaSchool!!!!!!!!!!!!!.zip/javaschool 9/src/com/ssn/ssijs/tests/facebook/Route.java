/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.facebook;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Route {
  private List<Person> route = new ArrayList<>();

  public Route(List<Person> route) {
    this.route = route;
  }

  public Route() {
    //
  }

  public boolean contains(Person line) {
    return route.contains(line);
  }

  public void add(Person line) {
    route.add(line);
  }

  public void removeLast() {
    route.remove(route.size() - 1);
  }

  @Override
  public Route clone() {
    return new Route(new ArrayList<Person>(this.route));
  }

  public void show() {
    for (int i = 0; i < route.size(); i++) {
      System.out.print("-" + route.get(i));
    }
    System.out.println();
  }
}
