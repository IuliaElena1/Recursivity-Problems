/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.facebook;

import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class PersonClient {
  public static void main(String[] args) {
    Facebook fb = new Facebook();

    fb.add("Ion");
    fb.add("Maria");
    fb.add("Mircea");
    fb.add("Gheo");
    fb.add("Gigi");
    fb.add("Elena");
    fb.add("Simona");
    fb.add("Florina");
    fb.add("Ana");
    fb.add("Silviu");

    fb.addRelation("Maria", "Ion");
    fb.addRelation("Simona", "Elena");
    fb.addRelation("Gigi", "Gheo");
    fb.addRelation("Mircea", "Maria");
    fb.addRelation("Mircea", "Silviu");
    fb.addRelation("Silviu", "Ana");
    fb.addRelation("Silviu", "Maria");

    fb.showPath("Ion", "Ana");
    List<Route> allSolutions = fb.showPath("Ion", "Ana");
    for (Route r : allSolutions) {
      r.show();
    }
  }
}
