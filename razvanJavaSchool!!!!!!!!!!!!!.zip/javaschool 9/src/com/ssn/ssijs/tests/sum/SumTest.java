/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.sum;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SumTest {
  Sum sum = new SumImpl();

  @Test
  public void test1() {
    List<List<Integer>> sol = sum.getSums(new int[] { 1, 2, 3, 4 }, 5);
    for (List<Integer> l : sol) {
      Collections.sort(l);
    }
    assertEquals(2, sol.size());
    assertTrue(sol.contains(Arrays.asList(1, 4)));
    assertTrue(sol.contains(Arrays.asList(2, 3)));
  }

  @Test
  public void test2() {
    List<List<Integer>> sol = sum.getSums(new int[] { 1, 2, 3, 5, 7 }, 10);
    for (List<Integer> l : sol) {
      Collections.sort(l);
    }
    assertEquals(3, sol.size());
    assertTrue(sol.contains(Arrays.asList(2, 3, 5)));
    assertTrue(sol.contains(Arrays.asList(3, 7)));
    assertTrue(sol.contains(Arrays.asList(1, 2, 7)));
  }

  @Test
  public void test3() {
    List<List<Integer>> sol = sum.getSums(new int[] { 1, 2, 3, 4, 5, 7, 8 }, 20);
    for (List<Integer> l : sol) {
      Collections.sort(l);
    }
    assertEquals(6, sol.size());
    assertTrue(sol.contains(Arrays.asList(1, 2, 4, 5, 8)));
    assertTrue(sol.contains(Arrays.asList(1, 3, 4, 5, 7)));
    assertTrue(sol.contains(Arrays.asList(1, 4, 7, 8)));
    assertTrue(sol.contains(Arrays.asList(2, 3, 7, 8)));
    assertTrue(sol.contains(Arrays.asList(3, 4, 5, 8)));
    assertTrue(sol.contains(Arrays.asList(5, 7, 8)));
  }

}
