/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.sum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SumImpl implements Sum {
  public static void main(String[] args) {
    System.out.println(new SumImpl().getSums(new int[] { 1, 2, 3, 4 }, 5));
  }

  @Override
  public List<List<Integer>> getSums(int[] arr, int n) {
    List<List<Integer>> result = new ArrayList<>();

    if (n == 0) {
      result.add(Arrays.asList());
      return result;
    }

    for (int i = 0; i < arr.length; i++) {
      List<List<Integer>> sums = getSums(getRestOfElements(arr, i), n - arr[i]);
      for (List<Integer> partialResult : sums) {
        List<Integer> res = new ArrayList<>();
        res.add(arr[i]);
        res.addAll(partialResult);
        result.add(res);
      }
    }

    return result;
  }

  private int[] getRestOfElements(int[] arr, int pos) {
    int[] result = new int[arr.length - 1];
    int counter = 0;
    for (int i = 0; i < arr.length; i++) {
      if (i > pos) {
        result[counter++] = arr[i];
      }
    }
    return result;
  }

}
