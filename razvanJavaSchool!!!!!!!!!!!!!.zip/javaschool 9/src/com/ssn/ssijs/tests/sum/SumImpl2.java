/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.sum;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SumImpl2 implements Sum {
  List<List<Integer>> result = new ArrayList<>();
  List<Integer> solution = new ArrayList<>();

  @Override
  public List<List<Integer>> getSums(int[] arr, int n) {
    if (n == 0) {
      result.add(new ArrayList<Integer>(solution));
      return result;
    }

    for (int i = 0; i < arr.length; i++) {
      solution.add(arr[i]);
      getSums(getRestOfElements(arr, i), n - arr[i]);
      solution.remove(solution.size() - 1);
    }

    return result;
  }

  public static void main(String[] args) {
    SumImpl2 test = new SumImpl2();
    System.out.println(test.getSums(new int[] { 1, 2, 3, 4 }, 5));
    System.out.println(test.getSums(new int[] { 1, 2, 3, 4 }, 5));
  }

  private int[] getRestOfElements(int[] arr, int pos) {
    int[] result = new int[arr.length - 1];
    int counter = 0;
    for (int i = 0; i < arr.length; i++) {
      if (i > pos) {
        result[counter++] = arr[i];
      }
    }
    return result;
  }

}
