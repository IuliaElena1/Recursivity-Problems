/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.stairs;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class StairsClimberTest {
  StairsClimber sc = new StairsImpl();

  @Test
  public void test00() {
    List<Integer> l1 = Arrays.asList(1);
    List<List<Integer>> sol = sc.findSolution(1);
    assertEquals(1, sol.size());
    assertTrue(sol.contains(l1));
  }

  @Test
  public void test0() {
    List<Integer> l1 = Arrays.asList(1, 1);
    List<Integer> l2 = Arrays.asList(2);
    List<List<Integer>> sol = sc.findSolution(2);
    assertEquals(2, sol.size());
    assertTrue(sol.contains(l1));
    assertTrue(sol.contains(l2));
  }

  @Test
  public void test1() {
    List<Integer> l1 = Arrays.asList(1, 1, 1);
    List<Integer> l2 = Arrays.asList(1, 2);
    List<Integer> l3 = Arrays.asList(2, 1);
    List<List<Integer>> sol = sc.findSolution(3);
    assertEquals(3, sol.size());
    assertTrue(sol.contains(l1));
    assertTrue(sol.contains(l2));
    assertTrue(sol.contains(l3));
  }

  @Test
  public void test2() {
    List<Integer> l1 = Arrays.asList(1, 1, 1, 1);
    List<Integer> l2 = Arrays.asList(1, 1, 2);
    List<Integer> l3 = Arrays.asList(2, 1, 1);
    List<Integer> l4 = Arrays.asList(1, 2, 1);
    List<Integer> l5 = Arrays.asList(2, 2);
    List<List<Integer>> sol = sc.findSolution(4);
    assertEquals(5, sol.size());
    assertTrue(sol.contains(l1));
    assertTrue(sol.contains(l2));
    assertTrue(sol.contains(l3));
    assertTrue(sol.contains(l4));
    assertTrue(sol.contains(l5));
  }

  @Test
  public void test3() {
    List<Integer> l1 = Arrays.asList(1, 1, 1, 1, 1);
    List<Integer> l2 = Arrays.asList(1, 1, 1, 2);
    List<Integer> l3 = Arrays.asList(1, 1, 2, 1);
    List<Integer> l4 = Arrays.asList(1, 2, 1, 1);
    List<Integer> l5 = Arrays.asList(2, 1, 1, 1);
    List<Integer> l6 = Arrays.asList(2, 2, 1);
    List<Integer> l7 = Arrays.asList(2, 1, 2);
    List<Integer> l8 = Arrays.asList(1, 2, 2);
    List<List<Integer>> sol = sc.findSolution(5);
    assertEquals(8, sol.size());
    assertTrue(sol.contains(l1));
    assertTrue(sol.contains(l2));
    assertTrue(sol.contains(l3));
    assertTrue(sol.contains(l4));
    assertTrue(sol.contains(l5));
    assertTrue(sol.contains(l6));
    assertTrue(sol.contains(l7));
    assertTrue(sol.contains(l8));
  }

}
