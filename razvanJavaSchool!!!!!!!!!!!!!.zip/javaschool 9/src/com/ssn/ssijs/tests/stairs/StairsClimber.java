/*
 * Copyright (c) 2018 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cbar/iba_test7/src/com/ssn/ssijs/tests/test7/StairsClimber.java,v 1.1 2018/08/06 09:02:01 cbar Exp $
 */

package com.ssn.ssijs.tests.stairs;

import java.util.List;

public interface StairsClimber {
  List<List<Integer>> findSolution(int height);
}
