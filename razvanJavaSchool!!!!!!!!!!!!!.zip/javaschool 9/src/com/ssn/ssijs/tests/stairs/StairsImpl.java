/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.stairs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class StairsImpl implements StairsClimber {

  @Override
  public List<List<Integer>> findSolution(int height) {
    List<List<Integer>> result = new ArrayList<>();

    if (height <= 0) {
      result.add(Arrays.asList());
      return result;
    }

    for (int i = 1; i <= 2; i++) {
      if (i <= height) {
        List<List<Integer>> temp = findSolution(height - i);
        for (List<Integer> list : temp) {
          List<Integer> l1 = new ArrayList<>();
          l1.add(i);
          l1.addAll(list);
          result.add(l1);
        }
      }
    }

    return result;
  }

}
