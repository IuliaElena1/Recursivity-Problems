/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ResultGrila extends Result {
  private double correctAnswers;

  public ResultGrila(Test test, double correctAnswers) {
    super(test);
    this.correctAnswers = correctAnswers;
  }

  @Override
  public String toString() {
    return "ResultGrila [correctAnswers=" + correctAnswers + "]";
  }

  @Override
  public String getStringForHTML() {
    return DF.format(getNota());
  }

  @Override
  public double getNota() {
    return 10 * correctAnswers / ((TestGrila) test).getNrQuestions();
  }

}
