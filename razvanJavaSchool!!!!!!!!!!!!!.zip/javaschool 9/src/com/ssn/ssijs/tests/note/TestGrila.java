/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestGrila extends Test {

  private double nrQuestions;

  public TestGrila(String[] splits) {
    super(splits[0], Integer.parseInt(splits[1]));
    nrQuestions = Integer.parseInt(splits[3]);
  }

  @Override
  public Result createResult(String[] splits) {
    return new ResultGrila(this, Double.parseDouble(splits[2]));
  }

  public double getNrQuestions() {
    return nrQuestions;
  }

}
