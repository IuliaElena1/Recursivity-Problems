/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ResultAdmis extends Result {

  private boolean admis;

  public ResultAdmis(Test test, boolean admis) {
    super(test);
    this.admis = admis;
  }

  @Override
  public String getStringForHTML() {
    return admis ? "Admis" : "Respins";
  }

  @Override
  public double getNota() {
    return admis ? 10 : 4;
  }

}
