/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestFactory {

  public Test createTest(String s) {
    if (s.startsWith("G")) {
      return new TestGrila(s.split("[()\\[\\]]"));
    }
    if (s.startsWith("P")) {
      return new TestPractic(s.split("[()\\[\\]]"));
    }
    if (s.startsWith("AR")) {
      return new TestAdmis(s.split("[()\\[\\]]"));
    }
    throw new RuntimeException("Invalid test type: " + s);
  }

}
