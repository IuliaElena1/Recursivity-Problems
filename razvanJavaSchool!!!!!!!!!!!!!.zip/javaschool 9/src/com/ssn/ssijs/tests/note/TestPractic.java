/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestPractic extends Test {

  public TestPractic(String[] splits) {
    super(splits[0], Integer.parseInt(splits[1]));
  }

  @Override
  public Result createResult(String[] splits) {
    double notaImpl = Double.parseDouble(splits[2]);
    double notaFunc = Double.parseDouble(splits[3]);
    return new ResultPractic(this, notaImpl, notaFunc);
  }

}
