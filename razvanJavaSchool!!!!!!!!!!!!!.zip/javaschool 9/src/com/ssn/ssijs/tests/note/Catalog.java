/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Catalog {
  private List<Student> students = new ArrayList<>();
  private List<Test> tests = new ArrayList<>();

  public static void main(String[] args) throws IOException {
    Catalog catalog = new Catalog();
    catalog.readData();
    catalog.generateHTML();
  }

  private void generateHTML() throws FileNotFoundException {
    System.out.println(students);
    Collections.sort(students);

    PrintWriter pw = new PrintWriter(new File("output.html"));

    pw.println("<TABLE border='1'");

    pw.println("<TR>");
    pw.println("<TH>" + "" + "</TH>");

    for (Test test : tests) {
      pw.println("<TH>" + test + "</TH>");
    }

    pw.println("<TH>Media</TH>");

    pw.println("</TR>");

    for (Student student : students) {
      pw.println("<TR>");
      pw.println("<TD>" + student.getName() + "</TD>");

      for (Test test : tests) {
        Result result = student.getResultByTest(test);

        pw.println("<TD>" + (result != null ? result.getStringForHTML() : "--") + "</TD>");
      }

      pw.println("<TD>" + Result.DF.format(student.getMedia()) + "</TD>");
      pw.println("</TR>");
    }

    pw.println("</TABLE>");

    pw.close();
  }

  private void readData() throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("rezultate.txt")));

    readStudents(br.readLine());
    readTests(br.readLine());

    while (true) {
      String s = br.readLine();
      if (s == null) {
        break;
      }

      readResult(s);
    }

    br.close();
  }

  private void readResult(String line) {
    String[] splits = line.split(",");
    String studentName = splits[0].trim();
    String testName = splits[1].trim();

    Student student = getStudentByName(studentName);
    Test test = getTestById(testName);
    Result result = test.createResult(splits);
    student.addResult(result);
  }

  private Student getStudentByName(String name) {
    for (Student s : students) {
      if (s.hasName(name)) {
        return s;
      }
    }
    return null;
  }

  private Test getTestById(String id) {
    for (Test t : tests) {
      if (t.hasId(id)) {
        return t;
      }
    }
    return null;
  }

  private void readTests(String line) {
    TestFactory tf = new TestFactory();
    String[] splits = line.split(",");
    for (String s : splits) {
      tests.add(tf.createTest(s.trim()));
    }
  }

  private void readStudents(String line) {
    String[] splits = line.split(",");
    for (String s : splits) {
      students.add(new Student(s.trim()));
    }
  }

}
