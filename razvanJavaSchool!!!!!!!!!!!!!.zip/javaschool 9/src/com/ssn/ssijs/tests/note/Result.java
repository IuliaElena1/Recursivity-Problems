/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

import java.text.DecimalFormat;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public abstract class Result {
  protected final static DecimalFormat DF = new DecimalFormat("#.00");

  protected Test test;

  public Result(Test test) {
    super();
    this.test = test;
  }

  @Override
  public String toString() {
    return "Result [test=" + test + "]";
  }

  public Test getTest() {
    return test;
  }

  public abstract String getStringForHTML();

  public abstract double getNota();

}
