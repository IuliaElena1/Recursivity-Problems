/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ResultPractic extends Result {

  private double notaImpl;
  private double notaFunc;

  public ResultPractic(Test test, double notaImpl, double notaFunc) {
    super(test);
    this.notaImpl = notaImpl;
    this.notaFunc = notaFunc;
  }

  @Override
  public String toString() {
    return "ResultPractic [notaImpl=" + notaImpl + ", notaFunc=" + notaFunc + "]";
  }

  @Override
  public String getStringForHTML() {
    return DF.format(getNota()) + //
      " (" + DF.format(notaFunc) + //
      "-" + DF.format(notaImpl) + ")";
  }

  @Override
  public double getNota() {
    return (notaFunc + notaImpl) / 2;
  }

}
