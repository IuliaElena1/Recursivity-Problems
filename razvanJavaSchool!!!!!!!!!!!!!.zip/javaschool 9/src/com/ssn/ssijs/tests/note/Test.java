/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public abstract class Test {
  private String id;
  private int weight;

  public Test(String id, int weight) {
    this.id = id;
    this.weight = weight;
  }

  public boolean hasId(String id2) {
    return id.equals(id2);
  }

  public abstract Result createResult(String[] splits);

  @Override
  public String toString() {
    return id;
  }

  public double getWeight() {
    return weight;
  }

}
