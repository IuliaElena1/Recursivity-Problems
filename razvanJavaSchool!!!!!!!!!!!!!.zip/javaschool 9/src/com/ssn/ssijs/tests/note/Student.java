/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.note;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Student implements Comparable<Student> {

  private String name;
  private List<Result> results = new ArrayList<>();

  public Student(String name) {
    this.name = name;
  }

  public boolean hasName(String name2) {
    return name.equals(name2);
  }

  @Override
  public String toString() {
    return "Student [name=" + name + ", results=" + results + "]";
  }

  public void addResult(Result result) {
    results.add(result);
  }

  public String getName() {
    return name;
  }

  public Result getResultByTest(Test test) {
    for (Result result : results) {
      if (result.getTest() == test) {
        return result;
      }
    }
    return null;
  }

  public double getMedia() {
    double sum = 0;
    double sumWeights = 0;
    for (Result result : results) {
      sum += result.getNota() * result.getTest().getWeight();
      sumWeights += result.getTest().getWeight();
    }
    return sum / sumWeights;
  }

  @Override
  public int compareTo(Student student) {
    return (int) (100 * -(this.getMedia() - student.getMedia()));
  }

}
