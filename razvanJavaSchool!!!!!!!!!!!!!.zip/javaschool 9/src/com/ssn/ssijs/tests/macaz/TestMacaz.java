
package com.ssn.ssijs.tests.macaz;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/*
 * Copyright (c) 2014 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestMacaz {
  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
    System.setErr(new PrintStream(errContent));
  }

  @After
  public void cleanUpStreams() {
    System.setOut(null);
    System.setErr(null);
  }

  @Test
  public void test1() {
    Depot dep = getImplementation();

    Object l1 = dep.addLine("L1");
    Object l2 = dep.addLine("L2");
    Object l3 = dep.addLine("L3");
    Object l4 = dep.addLine("L4");
    Object l5 = dep.addLine("L5");
    Object l6 = dep.addLine("L6");
    Object l7 = dep.addLine("L7");
    Object l8 = dep.addLine("L8");

    Object m1 = dep.addSwitch("M1");
    Object m2 = dep.addSwitch("M2");
    Object m3 = dep.addSwitch("M3");
    Object m4 = dep.addSwitch("M4");

    dep.setConnections(m1, l1, new Object[] { l2, l5 });
    dep.setConnections(m2, l3, new Object[] { l2, l4 });
    dep.setConnections(m3, l6, new Object[] { l4, l7 });
    dep.setConnections(m4, l8, new Object[] { l5, l7 });

    dep.showPath(l1, l6);

    assertEquals(outContent.toString().contains("Switch M1 to 1\r\nMove train from L1 to L2\r\nMove train from L2 to L3\r\nSwitch M2 to 2\r\nMove train from L3 to L4\r\nMove train from L4 to L6"), true);
    assertEquals(outContent.toString().contains("Switch M1 to 2\r\nMove train from L1 to L5\r\nMove train from L5 to L8\r\nSwitch M4 to 2\r\nMove train from L8 to L7\r\nMove train from L7 to L6"), true);

  }

  @Test
  public void test2() {
    Depot dep = getImplementation();

    Object l1 = dep.addLine("L1");
    Object l2 = dep.addLine("L2");
    Object l3 = dep.addLine("L3");
    Object l4 = dep.addLine("L4");
    Object l5 = dep.addLine("L5");
    Object l6 = dep.addLine("L6");
    Object l7 = dep.addLine("L7");
    Object l8 = dep.addLine("L8");

    Object m1 = dep.addSwitch("M1");
    Object m2 = dep.addSwitch("M2");
    Object m3 = dep.addSwitch("M3");
    Object m4 = dep.addSwitch("M4");

    dep.setConnections(m1, l1, new Object[] { l2, l5 });
    dep.setConnections(m2, l3, new Object[] { l2, l4 });
    dep.setConnections(m3, l6, new Object[] { l4, l7 });
    dep.setConnections(m4, l8, new Object[] { l5, l7 });

    dep.showPath(l4, l3);

    assertEquals(outContent.toString().contains("Move train from L4 to L3"), true);
    assertEquals(outContent.toString().contains("Move train from L4 to L6\r\nSwitch M3 to 2\r\nMove train from L6 to L7\r\nMove train from L7 to L8\r\nSwitch M4 to 1\r\nMove train from L8 to L5\r\nMove train from L5 to L1\r\nSwitch M1 to 1\r\nMove train from L1 to L2\r\nMove train from L2 to L3\r\n"), true);

  }

  @Test
  public void test3() {
    Depot dep = getImplementation();

    Object l1 = dep.addLine("L1");
    Object l2 = dep.addLine("L2");
    Object l3 = dep.addLine("L3");
    Object l4 = dep.addLine("L4");
    Object l5 = dep.addLine("L5");
    Object l6 = dep.addLine("L6");
    Object l7 = dep.addLine("L7");
    Object l8 = dep.addLine("L8");

    Object m1 = dep.addSwitch("M1");
    Object m2 = dep.addSwitch("M2");
    Object m3 = dep.addSwitch("M3");
    Object m4 = dep.addSwitch("M4");

    dep.setConnections(m1, l1, new Object[] { l2, l5 });
    dep.setConnections(m2, l3, new Object[] { l2, l4 });
    dep.setConnections(m3, l6, new Object[] { l4, l7 });
    dep.setConnections(m4, l8, new Object[] { l5, l7 });

    dep.showPath(l2, l7);

    assertEquals(outContent.toString().contains("Move train from L2 to L1\r\nSwitch M1 to 2\r\nMove train from L1 to L5\r\nMove train from L5 to L8\r\nSwitch M4 to 2\r\nMove train from L8 to L7"), true);
    assertEquals(outContent.toString().contains("Move train from L2 to L3\r\nSwitch M2 to 2\r\nMove train from L3 to L4\r\nMove train from L4 to L6\r\nSwitch M3 to 2\r\nMove train from L6 to L7"), true);

  }

  @Test
  public void test4() {
    Depot dep = getImplementation();

    Object l1 = dep.addLine("L1");
    Object l2 = dep.addLine("L2");
    Object l3 = dep.addLine("L3");

    Object m1 = dep.addSwitch("M1");

    dep.setConnections(m1, l1, new Object[] { l2, l3 });

    dep.showPath(l1, l3);

    assertEquals(outContent.toString().contains("PATH 1\r\nSwitch M1 to 2\r\nMove train from L1 to L3"), true);
    assertEquals(outContent.toString().contains("PATH 2"), false);

    dep.showPath(l1, l2);

    assertEquals(outContent.toString().contains("PATH 1\r\nSwitch M1 to 1\r\nMove train from L1 to L2"), true);
    assertEquals(outContent.toString().contains("PATH 2"), false);

    dep.showPath(l2, l3);

    assertTrue(outContent.toString().contains("PATH 1\r\nMove train from L2 to L1\r\nSwitch M1 to 2\r\nMove train from L1 to L3"));
    assertEquals(outContent.toString().contains("PATH 2"), false);

  }

  /**
   * @return
   */
  private Depot getImplementation() {
    return new DepotImpl();
  }
}
