/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.macaz;

import java.util.HashMap;
import java.util.Map;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Line {
  private String id;
  private Map<Line, Transition> connections = new HashMap<Line, Transition>();

  public Line(String id) {
    this.id = id;
  }

  public boolean hasId(String id) {
    return this.id.equals(id);
  }

  public void addConnection(Line line, Transition transition) {
    connections.put(line, transition);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Line other = (Line) obj;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    return true;
  }

  public Map<Line, Transition> getConnection() {
    return connections;
  }

  public void showTransition(Line to) {
    Transition transition = connections.get(to);
    transition.show();
    System.out.println("Move train from " + this.id + " to " + to.id);
  }

}
