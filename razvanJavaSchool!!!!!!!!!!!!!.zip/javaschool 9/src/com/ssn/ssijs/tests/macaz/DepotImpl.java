/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.macaz;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DepotImpl implements Depot {
  private List<Line> lines = new ArrayList<>();
  private int solutionCounter = 0;

  @Override
  public Object addLine(String id) {
    Line line = getLineById(id);
    if (line == null) {
      line = new Line(id);
      lines.add(line);
    }
    return line;
  }

  private Line getLineById(String id) {
    for (Line line : lines) {
      if (line.hasId(id)) {
        return line;
      }
    }
    return null;
  }

  @Override
  public Object addSwitch(String id) {
    return id;
  }

  @Override
  public void setConnections(Object mid, Object source, Object[] dest) {
    String switchId = (String) mid;
    Line sourceLine = (Line) source;
    Line[] destinationLines = //
      new Line[] { //
        (Line) dest[0], // pentru poz. 1 a macazului
        (Line) dest[1] // pentru poz. 2 a macazului
      };

    sourceLine.addConnection(destinationLines[0], new Transition(switchId, 1));
    sourceLine.addConnection(destinationLines[1], new Transition(switchId, 2));
    destinationLines[0].addConnection(sourceLine, new NoOperationTransition());
    destinationLines[1].addConnection(sourceLine, new NoOperationTransition());

  }

  @Override
  public void showPath(Object start, Object stop) {
    Line startLine = (Line) start;
    Line stopLine = (Line) stop;
    Route currentSolution = new Route();
    solutionCounter = 0;

    search(startLine, stopLine, currentSolution);
  }

  private void search(Line current, Line stop, Route solution) {
    // evitam buclele
    if (solution.contains(current)) {
      return;
    }

    // adaugam nodul curent la drumul curent
    solution.add(current);

    // daca am ajuns la solutie 
    if (current.equals(stop)) {
      // am ajuns la solutie
      solutionCounter++;
      System.out.println("PATH " + solutionCounter);
      solution.show();
    } else {
      Map<Line, Transition> neighbours = current.getConnection();
      for (Line neighbour : neighbours.keySet()) {
        search(neighbour, stop, solution);
      }
    }

    // foarte important stergem punctul adaugat cu add
    solution.removeLast();

  }

  @Override
  public void switchTrains(Object start, Object stop) {
    // TODO Auto-generated method stub

  }

}
