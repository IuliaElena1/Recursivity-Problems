/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.macaz;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Transition {
  private String switchId;
  private int position;

  public Transition() {
    // 
  }

  public Transition(String switchId, int position) {
    super();
    this.switchId = switchId;
    this.position = position;
  }

  public void show() {
    //    if (switchId != null) {
    System.out.println("Switch " + switchId + " to " + position);
    //    }
  }

}
