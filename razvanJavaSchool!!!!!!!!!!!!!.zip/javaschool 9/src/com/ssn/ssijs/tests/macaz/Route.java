/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.macaz;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Route {
  private List<Line> route = new ArrayList<Line>();

  public Route(List<Line> route) {
    this.route = route;
  }

  public Route() {
    //
  }

  public boolean contains(Line line) {
    return route.contains(line);
  }

  public void add(Line line) {
    route.add(line);
  }

  public void removeLast() {
    route.remove(route.size() - 1);
  }

  @Override
  public Route clone() {
    return new Route(new ArrayList<Line>(this.route));
  }

  public void show() {
    for (int i = 1; i < route.size(); i++) {
      Line from = route.get(i - 1);
      Line to = route.get(i);
      from.showTransition(to);
    }
  }
}
