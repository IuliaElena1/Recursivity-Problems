/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.depou;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class CargoWagon extends Wagon {
  public CargoWagon(String id, int weight) {
    super(id, weight);
  }

  @Override
  public String toString() {
    return super.toString() + "(" + getWeight() + ")";
  }

  @Override
  public boolean isValid() {
    return getWeight() >= 0;
  }

  @Override
  protected int getSpeedPenalty() {
    return weight;
  }
}
