/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.depou;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Train extends Entity {
  private Locomotive locomotive;
  private List<Wagon> wagons = new ArrayList<>();

  public Train(String id, Locomotive locomotive) {
    super(id);
    this.locomotive = locomotive;
  }

  public void addWagon(Wagon wagon) {
    wagons.add(wagon);
  }

  @Override
  public String toString() {
    String result = super.toString() + "(";

    result += (this.getSpeed() + ",");
    result += (locomotive.toString());
    Collections.sort(wagons);
    for (Wagon wagon : wagons) {
      result += ("," + wagon.toString());
    }

    return result += ")";
  }

  public int getSpeed() {
    int speed = this.locomotive.getMaxSpeed();

    for (Wagon wagon : wagons) {
      speed -= wagon.getSpeedPenalty();
    }

    return speed;
  }

  public boolean containsEntityById(String id) {
    if (locomotive.hasId(id)) {
      return true;
    }

    for (Wagon wagon : wagons) {
      if (wagon.hasId(id)) {
        return true;
      }
    }

    return false;
  }

  public boolean satisfies(int weight, int passengers) {
    int sumWeight = 0;
    int sumPassengers = 0;

    for (Wagon wagon : wagons) {
      if (wagon instanceof PassengerWagon) {
        sumPassengers += ((PassengerWagon) wagon).getMaxPassengers();
      }
      if (wagon instanceof CargoWagon) {
        sumWeight += ((CargoWagon) wagon).getWeight();
      }
    }

    return sumWeight > weight && sumPassengers > passengers;
  }

  public void removeWagon(Wagon wagon) {
    wagons.remove(wagon);
  }
}
