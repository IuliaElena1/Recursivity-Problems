/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.depou;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class PassengerWagon extends Wagon {
  private int maxPassengers;

  public PassengerWagon(String id, int weight, int maxPassengers) {
    super(id, weight);
    this.maxPassengers = maxPassengers;
  }

  @Override
  public String toString() {
    return super.toString() + "(" + getWeight() + "," + maxPassengers + ")";
  }

  @Override
  public boolean isValid() {
    return getWeight() >= 0 && maxPassengers >= 0;
  }

  @Override
  protected int getSpeedPenalty() {
    return (int) (weight + maxPassengers * 0.07);

  }

  /**
   * @return
   */
  public int getMaxPassengers() {
    return maxPassengers;
  }
}
