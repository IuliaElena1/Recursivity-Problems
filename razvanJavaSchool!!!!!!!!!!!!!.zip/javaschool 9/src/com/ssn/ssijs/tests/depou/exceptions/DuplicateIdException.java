/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/Team3/depou/src/com/ssn/ssijs/tests/depou/exceptions/DuplicateIdException.java,v 1.1 2019/02/26 09:05:23 calbu Exp $
 */

package com.ssn.ssijs.tests.depou.exceptions;

/**
 * @author <a href="mailto:aalbu@ssi-schaefer-noell.com">aalbu</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/26 09:05:23 $, $Author: calbu $
 */

public class DuplicateIdException extends Exception {

  private static final long serialVersionUID = 1L;

  public DuplicateIdException(String id) {
    super("Duplicate id: " + id);
  }
}
