/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/Team3/depou/src/com/ssn/ssijs/tests/depou/DepouTest.java,v 1.2 2019/02/26 09:52:37 calbu Exp $
 */

package com.ssn.ssijs.tests.depou;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.ssn.ssijs.tests.depou.exceptions.DuplicateIdException;
import com.ssn.ssijs.tests.depou.exceptions.TrainTooHeavyException;
import com.ssn.ssijs.tests.depou.exceptions.WagonAlreadyUsedException;

/**
 * @author <a href="mailto:aalbu@ssi-schaefer-noell.com">aalbu</a>
 * @version $Revision: 1.2 $, $Date: 2019/02/26 09:52:37 $, $Author: calbu $
 */

public class DepouTest {
  Depou depou = null;

  @Before
  public void setup() {
    depou = new DepouImpl();
  }

  @Test
  public void testAddLoco() throws IllegalArgumentException, DuplicateIdException {
    depou.addLoco("L01", 100);
    Object obj = depou.getObjectById("L01");
    assertEquals("L01(100)", obj.toString());
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddLocoDuplicate() throws IllegalArgumentException, DuplicateIdException {
    depou.addLoco("L01", 100);
    depou.addLoco("L01", 80);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddLocoNegativeSpeed() throws IllegalArgumentException, DuplicateIdException {
    depou.addLoco("L01", -100);
  }

  @Test
  public void testAddPassengerWagon() throws IllegalArgumentException, DuplicateIdException {
    depou.addPassengerWagon("PW1", 50, 20);
    Object obj = depou.getObjectById("PW1");
    assertEquals("PW1(50,20)", obj.toString());
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddPassWagonDuplicate() throws IllegalArgumentException, DuplicateIdException {
    depou.addPassengerWagon("PW1", 70, 18);
    depou.addPassengerWagon("PW1", 70, 18);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddPassWagonNegativeWeight() throws IllegalArgumentException, DuplicateIdException {
    depou.addPassengerWagon("PW1", -50, 100);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddPassWagonNegativePass() throws IllegalArgumentException, DuplicateIdException {
    depou.addPassengerWagon("PW1", 500, -5);
  }

  @Test
  public void testAddCargoWagon() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 50);
    Object obj = depou.getObjectById("CW1");
    assertEquals("CW1(50)", obj.toString());
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddCargoWagonDuplicate() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 60);
    depou.addCargoWagon("CW1", 60);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddCargoWagonNegativeWeight() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", -1);
  }

  @Test
  public void testAddTrain() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException, TrainTooHeavyException {
    depou.addLoco("L01", 200);
    depou.addCargoWagon("CW1", 50);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addTrain("T1", "L01");
    depou.addWagonToTrain("T1", "CW1");
    depou.addWagonToTrain("T1", "PW1");
    Object obj = depou.getObjectById("T1");
    assertEquals("T1(136,L01(200),CW1(50),PW1(10,60))", obj.toString());
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddTrainDuplicate() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException {
    depou.addLoco("L01", 200);
    depou.addCargoWagon("CW1", 50);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addTrain("T1", "L01");
    depou.addTrain("T1", "L02");
  }

  @Test(expected = TrainTooHeavyException.class)
  public void testAddTrainTooHeavy() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException, TrainTooHeavyException {
    depou.addLoco("L01", 100);
    depou.addCargoWagon("CW1", 40);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addTrain("T1", "L01");
    depou.addWagonToTrain("T1", "CW1");
    depou.addWagonToTrain("T1", "PW1");
  }

  @Test(expected = WagonAlreadyUsedException.class)
  public void testAddTrainWagonUsed() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException, TrainTooHeavyException {
    depou.addLoco("L01", 100);
    depou.addLoco("L02", 100);
    depou.addCargoWagon("CW1", 40);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addTrain("T1", "L01");
    depou.addWagonToTrain("T1", "CW1");
    depou.addTrain("T2", "L02");
    depou.addWagonToTrain("T2", "CW1");
  }

  @Test(expected = WagonAlreadyUsedException.class)
  public void testAddTrainLocoUsed() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException {
    depou.addLoco("L01", 100);
    depou.addCargoWagon("CW1", 70);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addTrain("T1", "L01");
    depou.addTrain("T2", "L01");
  }

  @Test
  public void testAddTrainAutomaticaly() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 70);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addPassengerWagon("PW3", 15, 70);
    depou.addLoco("L01", 250);
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T1", 100, 110);
    Object obj = depou.getObjectById("T1");
    assertEquals("T1(104,L01(250),CW1(70),CW2(50),PW1(10,60),PW2(5,100))", obj.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddTrainAutomaticalyWithNoWagon() throws IllegalArgumentException, DuplicateIdException {
    depou.addLoco("L01", 200);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addPassengerWagon("PW2", 4, 40);
    depou.createTrainAutomaticaly("T1", 300, 150);
  }

  @Test
  public void testAddTrainAutomaticalyWhithTrainTooHeavy() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 70);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW1", 10, 20);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addLoco("L01", 185);
    depou.createTrainAutomaticaly("T1", 100, 60);
    Object obj = depou.getObjectById("T1");
    assertEquals("T1(53,L01(185),CW1(70),CW2(50),PW2(5,100))", obj.toString());
  }

  @Test()
  public void testAddTrainAutomaticalyWithWagonAlreadyUsed() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException, TrainTooHeavyException {
    depou.addLoco("L01", 200); //folosit de T1
    depou.addCargoWagon("CW1", 50); //folosit de T1
    depou.addPassengerWagon("PW1", 3, 20);
    depou.addCargoWagon("CW2", 40);
    depou.addTrain("T1", "L01");
    depou.addWagonToTrain("T1", "CW1");
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T2", 30, 20);
    Object obj = depou.getObjectById("T2");
    assertEquals("T2(56,L02(100),CW2(40),PW1(3,20))", obj.toString());
  }

  @Test(expected = WagonAlreadyUsedException.class)
  public void testAddTrainAutomaticalyWithWagonAlreadyUsed2() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException, TrainTooHeavyException {
    depou.addCargoWagon("CW1", 70); //folosit de T1
    depou.addPassengerWagon("PW1", 10, 60); //folosit de T1
    depou.addCargoWagon("CW2", 50); //folosit de T1
    depou.addPassengerWagon("PW2", 5, 100); // folosit de T1
    depou.addLoco("L01", 250); // folosit de T1
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T1", 100, 110);
    depou.addTrain("T2", "L02");
    depou.addWagonToTrain("T2", "CW2");
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddTrainAutomaticalyDuplicate() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 70);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW1", 10, 20);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addLoco("L01", 185);
    depou.createTrainAutomaticaly("T1", 100, 60);
    depou.createTrainAutomaticaly("T1", 50, 40);
  }

  @Test(expected = DuplicateIdException.class)
  public void testAddTrainAutomaticalyDuplicate2() throws IllegalArgumentException, DuplicateIdException, WagonAlreadyUsedException {
    depou.addCargoWagon("CW1", 70);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addLoco("L01", 250);
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T1", 100, 110);
    depou.addTrain("T1", "L02");
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddTrainAutomaticalyWithNegativeWeight() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 70);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addPassengerWagon("PW3", 15, 70);
    depou.addLoco("L01", 250);
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T1", -100, 110);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddTrainAutomaticalyWithNegativePass() throws IllegalArgumentException, DuplicateIdException {
    depou.addCargoWagon("CW1", 70);
    depou.addPassengerWagon("PW1", 10, 60);
    depou.addCargoWagon("CW2", 50);
    depou.addPassengerWagon("PW2", 5, 100);
    depou.addPassengerWagon("PW3", 15, 70);
    depou.addLoco("L01", 250);
    depou.addLoco("L02", 100);
    depou.createTrainAutomaticaly("T1", 100, -110);
  }

}
