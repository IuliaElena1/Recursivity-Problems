/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/Team3/depou/src/com/ssn/ssijs/tests/depou/Depou.java,v 1.1 2019/02/26 09:05:23 calbu Exp $
 */

package com.ssn.ssijs.tests.depou;

import com.ssn.ssijs.tests.depou.exceptions.DuplicateIdException;
import com.ssn.ssijs.tests.depou.exceptions.TrainTooHeavyException;
import com.ssn.ssijs.tests.depou.exceptions.WagonAlreadyUsedException;

/**
 * @author <a href="mailto:aalbu@ssi-schaefer-noell.com">aalbu</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/26 09:05:23 $, $Author: calbu $
 */

public interface Depou {

  public void addLoco(String id, int maxSpeed) throws DuplicateIdException, IllegalArgumentException;

  public void addPassengerWagon(String id, int weight, int maxPassengers) throws DuplicateIdException, IllegalArgumentException;

  public void addCargoWagon(String id, int weight) throws DuplicateIdException, IllegalArgumentException;

  public void addWagonToTrain(String id, String wagonId) throws WagonAlreadyUsedException, TrainTooHeavyException;

  public void addTrain(String id, String locoId) throws DuplicateIdException, WagonAlreadyUsedException;

  /**
   * Vagoanele se adauga in tren in ordine alfabetica
   * @param id
   * @param weight
   * @param passengers
   * @throws DuplicateIdException 
   * @throws IllegalArgumentException 
   */
  public void createTrainAutomaticaly(String id, int weight, int passengers) throws DuplicateIdException, IllegalArgumentException;

  /**
   * Locomotiva: "id(maxSpeed)"
   * Cargo Wagon: "id(weight)"
   * Passenger Wagon: "id(weight,maxPassengers)"
   * Train: "TrainId(maxSpeed,locomotiva.toString(),cargoWagon.toString(),passengerWagon.toString(),...)"
   * @param id
   * @return 
   */
  public Object getObjectById(String id);

}
