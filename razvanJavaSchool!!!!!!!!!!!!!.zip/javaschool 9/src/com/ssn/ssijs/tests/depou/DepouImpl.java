/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.depou;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ssn.ssijs.tests.depou.exceptions.DuplicateIdException;
import com.ssn.ssijs.tests.depou.exceptions.TrainTooHeavyException;
import com.ssn.ssijs.tests.depou.exceptions.WagonAlreadyUsedException;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DepouImpl implements Depou {
  List<Entity> entities = new ArrayList<>();

  @Override
  public void addLoco(String id, int maxSpeed) throws DuplicateIdException, IllegalArgumentException {
    Locomotive l = new Locomotive(id, maxSpeed);
    if (entities.contains(l)) {
      throw new DuplicateIdException(id);
    }

    if (maxSpeed < 0) {
      throw new IllegalArgumentException();
    }

    entities.add(l);
  }

  @Override
  public void addPassengerWagon(String id, int weight, int maxPassengers) throws DuplicateIdException, IllegalArgumentException {
    addWagon(new PassengerWagon(id, weight, maxPassengers));
  }

  @Override
  public void addCargoWagon(String id, int weight) throws DuplicateIdException, IllegalArgumentException {
    addWagon(new CargoWagon(id, weight));
  }

  private void addWagon(Wagon wagon) throws DuplicateIdException {
    if (entities.contains(wagon)) {
      throw new DuplicateIdException(wagon.getId());
    }

    if (!wagon.isValid()) {
      throw new IllegalArgumentException();
    }

    entities.add(wagon);
  }

  @Override
  public void addWagonToTrain(String id, String wagonId) throws WagonAlreadyUsedException, TrainTooHeavyException {
    Train train = (Train) getObjectById(id);
    Wagon wagon = (Wagon) getObjectById(wagonId);

    if (isItemUsedByATrain(wagonId)) {
      throw new WagonAlreadyUsedException(wagonId);
    }

    if (train.getSpeed() - wagon.getSpeedPenalty() < 50) {
      throw new TrainTooHeavyException(id);
    }

    train.addWagon(wagon);
    entities.remove(wagon);
  }

  @Override
  public void addTrain(String id, String locoId) throws DuplicateIdException, WagonAlreadyUsedException {
    Locomotive loco = (Locomotive) getObjectById(locoId);
    Train train = new Train(id, loco);

    if (entities.contains(train)) {
      throw new DuplicateIdException(id);
    }

    if (isItemUsedByATrain(locoId)) {
      throw new WagonAlreadyUsedException(locoId);
    }

    entities.add(train);
    entities.remove(loco);
  }

  @Override
  public void createTrainAutomaticaly(String id, int weight, int passengers) throws DuplicateIdException, IllegalArgumentException {
    Train train = new Train(id, null);
    if (entities.contains(train)) {
      throw new DuplicateIdException(id);
    }

    if (weight < 0 || passengers < 0) {
      throw new IllegalArgumentException();
    }

    Locomotive locomotive = findBestLocomotive();
    Train createdTrain = new Train(id, locomotive);

    createTrain(createdTrain, weight, passengers, getListOfWagons());

    if (!createdTrain.satisfies(weight, passengers)) {
      throw new IllegalArgumentException();
    }

    entities.add(createdTrain);
  }

  private void createTrain(Train train, int weight, int passengers, List<Wagon> wagons) {
    if (train.satisfies(weight, passengers)) {
      return;
    }

    Iterator<Wagon> iterator = wagons.iterator();

    while (iterator.hasNext()) {
      Wagon wagon = iterator.next();

      try {
        train.addWagon(wagon);
        ArrayList<Wagon> remainingWagons = new ArrayList<>(wagons);
        remainingWagons.remove(wagon);
        createTrain(train, weight, passengers, remainingWagons);

        if (train.satisfies(weight, passengers)) {
          return;
        } else {
          train.removeWagon(wagon);
        }
      } catch (Exception e) {
        e.printStackTrace();
        train.removeWagon(wagon);
      }

    }

  }

  private Locomotive findBestLocomotive() {
    Locomotive result = null;
    for (Entity entity : entities) {
      if (entity instanceof Locomotive) {
        Locomotive loco = (Locomotive) entity;
        if (result == null || loco.getMaxSpeed() > result.getMaxSpeed()) {
          result = loco;
        }
      }
    }
    return result;
  }

  @Override
  public Object getObjectById(String id) {
    for (Entity e : entities) {
      if (e.hasId(id)) {
        return e;
      }
    }
    return null;
  }

  public boolean isItemUsedByATrain(String id) {
    for (Entity entity : entities) {
      if (entity instanceof Train) {
        Train train = (Train) entity;
        if (train.containsEntityById(id)) {
          return true;
        }
      }
    }

    return false;
  }

  public List<Wagon> getListOfWagons() {
    List<Wagon> result = new ArrayList<>();

    for (Entity entity : entities) {
      if (entity instanceof Wagon) {
        result.add((Wagon) entity);
      }
    }

    return result;
  }

}
