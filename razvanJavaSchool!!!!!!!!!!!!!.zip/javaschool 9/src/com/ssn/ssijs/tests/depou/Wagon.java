/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.depou;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public abstract class Wagon extends Entity implements Comparable<Wagon> {
  protected int weight;

  public Wagon(String id, int weight) {
    super(id);
    this.setWeight(weight);
  }

  public abstract boolean isValid();

  protected abstract int getSpeedPenalty();

  /**
   * @return the weight
   */
  public int getWeight() {
    return weight;
  }

  /**
   * @param weight the weight to set
   */
  public void setWeight(int weight) {
    this.weight = weight;
  }

  @Override
  public int compareTo(Wagon wagon) {
    return this.getId().compareTo(wagon.getId());
  }
}
