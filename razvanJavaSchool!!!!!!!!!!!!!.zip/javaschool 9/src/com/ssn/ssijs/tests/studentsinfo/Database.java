/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ssn.ssijs.javaschool.collections.School;
import com.ssn.ssijs.javaschool.collections.StudentsInfo;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Database implements StudentsInfo {
  List<Student> students = new ArrayList<>();
  static Database instance = new Database();

  public static Database getInstance() {
    return instance;
  }

  @Override
  public void addStudent(String name, double average, int year, int from, School school) {
    students.add(new Student(name, school, year, from, average));
  }

  @Override
  public void addStudent(String name, double average) {
    students.add(new Student(name, average));
  }

  @Override
  public List<String> getStudentsInTerminalYears() {
    List<String> result = new ArrayList<>();
    for (Student student : students) {
      if (student.isInTerminalYear()) {
        result.add(student.getName());
      }
    }
    return result;
  }

  @Override
  public List<String> getStudentsBySchool(School school) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Map<School, Integer> getStudentsGroupBySchool() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Map<School, Integer> getStudentsPercentsGroupBySchool() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Map<School, Double> getStudentsAverageBySchool() {
    // TODO Auto-generated method stub
    return null;
  }

  public List<Student> getAllStudents() {
    return students;
  }

}
