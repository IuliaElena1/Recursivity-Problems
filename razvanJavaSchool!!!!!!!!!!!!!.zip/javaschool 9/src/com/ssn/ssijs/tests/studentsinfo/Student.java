/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import com.ssn.ssijs.javaschool.collections.School;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Student {
  private String name;
  private School school;
  private int year;
  private int from;
  private double avg;

  public Student(String name, School school, int year, int from, double avg) {
    super();
    this.name = name;
    this.school = school;
    this.year = year;
    this.from = from;
    this.avg = avg;
  }

  public Student(String name, double avg) {
    this.name = name;
    this.avg = avg;
  }

  @Override
  public String toString() {
    return "Student [name=" + name + ", school=" + school + ", year=" + year + ", from=" + from + ", avg=" + avg + "]";
  }

  public boolean isInTerminalYear() {
    return year == from;
  }

  public String getName() {
    return name;
  }

}
