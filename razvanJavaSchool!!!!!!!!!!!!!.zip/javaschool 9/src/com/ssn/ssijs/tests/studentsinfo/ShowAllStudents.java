/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import com.ssn.common.menus.MenuItem;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ShowAllStudents extends MenuItem {

  public ShowAllStudents(String option, String name) {
    super(option, name);
  }

  @Override
  protected void run() {
    System.out.println(Database.getInstance().getAllStudents());
  }

}
