/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import java.util.List;

import com.ssn.common.menus.MenuItem;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ShowTerminalStudents extends MenuItem {

  public ShowTerminalStudents(String option, String name) {
    super(option, name);
  }

  @Override
  protected void run() {
    List<String> data = Database.getInstance().getStudentsInTerminalYears();
    System.out.println(data);
  }

}
