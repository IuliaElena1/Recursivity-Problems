/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import com.ssn.common.menus.BackMenu;
import com.ssn.common.menus.Menu;
import com.ssn.common.menus.MenuItem;
import com.ssn.ssijs.javaschool.collections.School;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Application {
  public static void main(String[] args) {
    Application app = new Application();
    app.init();
    app.run();

  }

  private void init() {
    Database.getInstance().addStudent("Ion", 9, 3, 3, School.UVT);
    Database.getInstance().addStudent("Gheo", 8, 4, 4, School.UPT);
    Database.getInstance().addStudent("Mircea", 7, 2, 3, School.UVT);
    Database.getInstance().addStudent("vali", 6, 3, 4, School.UPT);
  }

  private void run() {
    Menu mainMenu = new Menu("", "Main menu");

    Menu adaugare = new Menu("1", "Add data");
    // adaugam submeniul adaugare la mainMenu
    mainMenu.addMenuItem(adaugare);
    mainMenu.addMenuItem(new ShowAllStudents("2", "View"));
    mainMenu.addMenuItem(new ShowTerminalStudents("3", "Show terminals"));

    // adaugam submeniul add student with school la meniul adaugare
    adaugare.addMenuItem(new AddStudentWithSchoolAction("1", "Add student with school"));
    MenuItem back = new BackMenu("0", "Back");
    adaugare.addMenuItem(back);
    adaugare.setBackOption(back);

    MenuItem exit = new BackMenu("0", "Exit");
    mainMenu.addMenuItem(exit);
    mainMenu.setBackOption(exit);

    mainMenu.doAction();
  }
}
