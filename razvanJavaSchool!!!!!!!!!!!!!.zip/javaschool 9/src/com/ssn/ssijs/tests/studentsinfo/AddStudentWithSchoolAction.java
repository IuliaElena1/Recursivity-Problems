/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.studentsinfo;

import com.ssn.common.keyboard.Keyboard;
import com.ssn.common.menus.MenuItem;
import com.ssn.ssijs.javaschool.collections.School;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class AddStudentWithSchoolAction extends MenuItem {
  private Keyboard keyboard = new Keyboard();

  public AddStudentWithSchoolAction(String option, String name) {
    super(option, name);
  }

  @Override
  protected void run() {
    String name = keyboard.readLineWithMessage("Name: ");
    int anul = Integer.parseInt(keyboard.readLineWithMessage("Anul: "));
    int from = Integer.parseInt(keyboard.readLineWithMessage("Din: "));
    double avg = Double.parseDouble(keyboard.readLineWithMessage("Average: "));
    School school = School.valueOf(keyboard.readLineWithMessage("Scoala: "));

    Database.getInstance().addStudent(name, avg, anul, from, school);
  }

}
