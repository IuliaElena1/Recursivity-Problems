/*
 * Copyright (c) 2018 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cmaracine/sma_test5/src/com/ssn/ssijs/tests/watermeters/exceptions/InvalidDateException.java,v 1.1 2018/07/30 09:41:57 cmaracine Exp $
 */

package com.ssn.ssijs.tests.watermeters.exceptions;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: 1.1 $, $Date: 2018/07/30 09:41:57 $, $Author: cmaracine $
 */

public class InvalidDateException extends WatermetersException {
  public InvalidDateException() {
    super("Invalid date");
  }
}
