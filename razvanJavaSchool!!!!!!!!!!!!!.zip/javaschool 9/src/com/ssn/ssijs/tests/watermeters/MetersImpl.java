/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.watermeters;

import java.util.ArrayList;
import java.util.List;

import com.ssn.ssijs.tests.watermeters.exceptions.InvalidDateException;
import com.ssn.ssijs.tests.watermeters.exceptions.InvalidReadingException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingAlreadyExistsException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingNotFoundException;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class MetersImpl implements Meters {
  List<Reading> readings = new ArrayList<>();

  @Override
  public void addReading(int year, String monthAsString, int hotWater, int coldWater) throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException {
    Month month = getMonthFromString(monthAsString);
    validateYear(year);

    Reading reading = getReadingByYearAndMonth(year, month);
    if (reading != null) {
      throw new ReadingAlreadyExistsException();
    }

    Reading previousReading = getPreviousReadingByYearAndMonth(year, month);

    if (previousReading != null && !previousReading.isNewReadingValid(coldWater, hotWater)) {
      throw new InvalidReadingException();
    }

    //    if (previousReading.getColdWater() > coldWater || //
    //        previousReading.getHotWater() > hotWater) {
    //
    //    }

    readings.add(new Reading(year, month, hotWater, coldWater));
  }

  private Reading getPreviousReadingByYearAndMonth(int year, Month month) {
    if (month == Month.IAN) {
      year--;
      month = Month.DEC;
    } else {
      month = Month.values()[month.ordinal() - 1];
    }

    return getReadingByYearAndMonth(year, month);
  }

  private void validateYear(int year) throws InvalidDateException {
    if (year < 0) {
      throw new InvalidDateException();
    }
  }

  private Month getMonthFromString(String monthAsString) throws InvalidDateException {
    try {
      return Month.valueOf(monthAsString.toUpperCase());
    } catch (IllegalArgumentException e) {
      throw new InvalidDateException();
    }
  }

  @Override
  public void removeReading(int year, String monthAsString) throws InvalidDateException, ReadingNotFoundException {
    Month month = getMonthFromString(monthAsString);
    validateYear(year);

    Reading reading = getReadingByYearAndMonth(year, month);
    if (reading == null) {
      throw new ReadingNotFoundException();
    }

    readings.remove(reading);
  }

  private Reading getReadingByYearAndMonth(int year, Month month) {
    for (Reading reading : readings) {
      if (reading.hasYearAndMonth(year, month)) {
        return reading;
      }
    }

    return null;
  }

  @Override
  public String getConsumptionInfo(int year, String monthAsString) throws InvalidDateException, ReadingNotFoundException {
    Month month = getMonthFromString(monthAsString);
    validateYear(year);

    Reading reading = getReadingByYearAndMonth(year, month);
    Reading previousReading = getPreviousReadingByYearAndMonth(year, month);

    if (reading == null || previousReading == null) {
      throw new ReadingNotFoundException();
    }

    return reading.getConsumptionInfo(previousReading);
  }

}
