/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.watermeters;

public class Reading {
  private int year;
  private Month month;
  private int hotWater;
  private int coldWater;

  public Reading(int year, Month month, int hotWater, int coldWater) {
    this.year = year;
    this.month = month;
    this.hotWater = hotWater;
    this.coldWater = coldWater;
  }

  @SuppressWarnings("hiding")
  public boolean hasYearAndMonth(int year, Month month) {
    return (this.year == year && this.month == month);
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((month == null) ? 0 : month.hashCode());
    result = prime * result + year;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Reading other = (Reading) obj;
    if (month != other.month)
      return false;
    if (year != other.year)
      return false;
    return true;
  }

  @SuppressWarnings("hiding")
  public boolean isNewReadingValid(int coldWater, int hotWater) {
    return coldWater >= this.coldWater && hotWater >= this.hotWater;
  }

  public String getConsumptionInfo(Reading previousReading) {
    // Apa calda: 101-100=1 | Apa rece: 154-150=4
    String result = "Apa calda: ";

    result += this.hotWater + "-" + previousReading.hotWater + "=" + (this.hotWater - previousReading.hotWater);
    result += " | Apa rece: ";
    result += this.coldWater + "-" + previousReading.coldWater + "=" + (this.coldWater - previousReading.coldWater);

    return result;
  }

}
