/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.watermeters;

import java.util.Scanner;

import com.ssn.ssijs.tests.watermeters.exceptions.InvalidDateException;
import com.ssn.ssijs.tests.watermeters.exceptions.InvalidReadingException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingAlreadyExistsException;
import com.ssn.ssijs.tests.watermeters.exceptions.WatermetersException;

public class Application {
  private Scanner scanner = new Scanner(System.in);
  private Meters database = new MetersImpl();

  public static void main(String[] args) throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException {
    Application app = new Application();
    app.init();
    app.run();
  }

  private void init() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException {
    database.addReading(2018, "dec", 100, 100);
    database.addReading(2019, "ian", 101, 102);
  }

  private void run() {
    loop: while (true) {
      showMenu();
      String input = scanner.nextLine();

      try {
        switch (input) {
          case "1":
            add();
            break;
          case "2":
            remove();
            break;
          case "3":
            display();
            break;
          case "4":
            break loop;
        }
      } catch (WatermetersException ex) {
        System.out.println(ex.getMessage());
      }
    }

    scanner.close();
  }

  private void display() throws WatermetersException {
    int year = readInt("Anul: ");
    String month = readString("Month: ");

    System.out.println(database.getConsumptionInfo(year, month));
  }

  private void remove() throws WatermetersException {
    int year = readInt("Anul: ");
    String month = readString("Month: ");

    database.removeReading(year, month);
  }

  private void add() throws WatermetersException {
    int year = readInt("Anul: ");
    String month = readString("Month: ");
    int hot = readInt("Apa calda: ");
    int cold = readInt("Apa rece: ");

    database.addReading(year, month, hot, cold);
  }

  private String readString(String msg) {
    System.out.print(msg);
    return scanner.nextLine();
  }

  private int readInt(String message) {
    System.out.print(message);
    int n = scanner.nextInt();
    scanner.nextLine();
    return n;
  }

  private void showMenu() {
    System.out.println("1. Adaugare");
    System.out.println("2. Stergere");
    System.out.println("3. Afisare");
    System.out.println("4. Iesire");
  }
}
