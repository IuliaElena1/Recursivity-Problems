/*
 * Copyright (c) 2018 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cmaracine/sma_test5/src/com/ssn/ssijs/tests/watermeters/Meters.java,v 1.3 2018/08/02 05:24:33 cmaracine Exp $
 */

package com.ssn.ssijs.tests.watermeters;

import com.ssn.ssijs.tests.watermeters.exceptions.InvalidDateException;
import com.ssn.ssijs.tests.watermeters.exceptions.InvalidReadingException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingAlreadyExistsException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingNotFoundException;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: 1.3 $, $Date: 2018/08/02 05:24:33 $, $Author: cmaracine $
 */

public interface Meters {
  public void addReading(int year, String month, int hotWater, int coldWater) throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException;

  public void removeReading(int year, String month) throws InvalidDateException, ReadingNotFoundException;

  /**
   * Returneaza datele despre consumul pe luna curenta in formatul:
  
  Apa calda: 101-100=1 | Apa rece: 154-150=4
   
  (luna precedenta-luna curenta=valoare)
  Atentie la spatii!!!!!!
   * @param year
   * @param month
   * @return
   * @throws InvalidDateException
   * @throws ReadingNotFoundException
   */
  public String getConsumptionInfo(int year, String month) throws InvalidDateException, ReadingNotFoundException;
}
