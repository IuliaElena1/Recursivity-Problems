/*
 * Copyright (c) 2018 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.watermeters;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.ssn.ssijs.tests.watermeters.exceptions.InvalidDateException;
import com.ssn.ssijs.tests.watermeters.exceptions.InvalidReadingException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingAlreadyExistsException;
import com.ssn.ssijs.tests.watermeters.exceptions.ReadingNotFoundException;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class MetersTest {
  Meters meters;

  @Before
  public void setUp() {
    meters = new MetersImpl();
  }

  @Test
  public void testAddWrongDate() throws InvalidReadingException, ReadingAlreadyExistsException {
    try {
      meters.addReading(2018, "qwe", 100, 150);
      fail("InvalidDateException not thrown");
    } catch (InvalidDateException e) {
      // 
    }
  }

  @Test
  public void testAddWrongReading() throws InvalidDateException, ReadingAlreadyExistsException {
    try {
      meters.addReading(2018, "ian", 100, 150);
      meters.addReading(2018, "feb", 99, 99);
      fail("InvalidReadingException not thrown");
    } catch (InvalidReadingException e) {
      // 
    }
  }

  @Test
  public void testAddGoodReading() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException {
    meters.addReading(2018, "ian", 100, 150);
    meters.addReading(2018, "feb", 100, 150);
  }

  @Test
  public void testReadingExists() throws InvalidDateException, InvalidReadingException {
    try {
      meters.addReading(2018, "ian", 100, 150);
      meters.addReading(2018, "ian", 101, 160);
      fail("ReadingAlreadyExistsException not thrown");
    } catch (ReadingAlreadyExistsException e) {
      // 
    }
  }

  @Test
  public void testReadingRemoveNotFound() throws InvalidDateException {
    try {
      meters.removeReading(2018, "ian");
      fail("ReadingNotFoundException not thrown");
    } catch (ReadingNotFoundException e) {
      // 
    }
  }

  @Test
  public void testReadingRemoveInvalidDate() throws ReadingNotFoundException {
    try {
      meters.removeReading(2018, "qwe");
      fail("InvalidDateException not thrown");
    } catch (InvalidDateException e) {
      // 
    }
  }

  @Test
  public void testRemove() throws InvalidDateException, ReadingNotFoundException, InvalidReadingException, ReadingAlreadyExistsException {
    meters.addReading(2018, "ian", 1, 1);
    meters.removeReading(2018, "ian");
    meters.addReading(2018, "ian", 1, 1);
  }

  @Test
  public void testConsumption1() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException, ReadingNotFoundException {
    meters.addReading(2018, "mar", 103, 156);
    meters.addReading(2018, "feb", 101, 152);
    meters.addReading(2018, "ian", 100, 150);
    assertEquals("Apa calda: 101-100=1 | Apa rece: 152-150=2", meters.getConsumptionInfo(2018, "feb"));
    assertEquals("Apa calda: 103-101=2 | Apa rece: 156-152=4", meters.getConsumptionInfo(2018, "mar"));
  }

  @Test
  public void testConsumption2() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException, ReadingNotFoundException {
    meters.addReading(2018, "feb", 103, 156);
    meters.addReading(2018, "ian", 101, 152);
    meters.addReading(2017, "dec", 100, 150);
    assertEquals("Apa calda: 101-100=1 | Apa rece: 152-150=2", meters.getConsumptionInfo(2018, "ian"));
    assertEquals("Apa calda: 103-101=2 | Apa rece: 156-152=4", meters.getConsumptionInfo(2018, "feb"));
  }

  @Test
  public void testConsumption3() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException, ReadingNotFoundException {
    meters.addReading(2018, "ian", 103, 156);
    meters.addReading(2017, "dec", 101, 152);
    meters.addReading(2017, "noi", 100, 150);
    assertEquals("Apa calda: 101-100=1 | Apa rece: 152-150=2", meters.getConsumptionInfo(2017, "dec"));
    assertEquals("Apa calda: 103-101=2 | Apa rece: 156-152=4", meters.getConsumptionInfo(2018, "ian"));
  }

  @Test
  public void testConsumption4() throws InvalidDateException, InvalidReadingException, ReadingAlreadyExistsException, ReadingNotFoundException {
    meters.addReading(2018, "IAN", 103, 156);
    meters.addReading(2017, "DEC", 101, 152);
    meters.addReading(2017, "NOI", 100, 150);
    assertEquals("Apa calda: 101-100=1 | Apa rece: 152-150=2", meters.getConsumptionInfo(2017, "dec"));
    assertEquals("Apa calda: 103-101=2 | Apa rece: 156-152=4", meters.getConsumptionInfo(2018, "ian"));
  }

  @Test
  public void testMonthComparison() {
    assertTrue(Month.IAN.compareTo(Month.FEB) < 0);
    assertTrue(Month.FEB.compareTo(Month.IAN) > 0);
    assertTrue(Month.FEB.compareTo(Month.FEB) == 0);
  }
}
