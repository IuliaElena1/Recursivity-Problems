/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.expression;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Expression2 {
  public static void main(String[] args) {
    // exp(3*2+5*7) = exp(3*2) + exp(5*7) = exp(3) * exp(2) + exp(5) * exp(7) =
    // 3 * 2 + 5 * 7
    System.out.println(booleanExp("3 * 2 = 1 * 2 + 4"));
  }

  private static boolean booleanExp(String s) {
    if (s.contains("=")) {
      int index = s.indexOf('=');
      String left = s.substring(0, index);
      String right = s.substring(index + 1);
      return exp(left) == exp(right);
    }
    return false;
  }

  private static int exp(String s) {
    if (s.contains("+")) {
      int index = s.indexOf('+');
      String left = s.substring(0, index);
      String right = s.substring(index + 1);
      return exp(left) + exp(right);
    }
    if (s.contains("*")) {
      int index = s.indexOf('*');
      String left = s.substring(0, index);
      String right = s.substring(index + 1);
      return exp(left) * exp(right);
    }
    return Integer.parseInt(s.trim());
  }
}
