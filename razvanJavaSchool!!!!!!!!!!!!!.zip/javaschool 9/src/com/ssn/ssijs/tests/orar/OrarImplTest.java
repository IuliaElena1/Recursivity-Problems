/*
 * Copyright (c) 2018 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cbar/iba_test8/src/com/ssn/ssijs/iba/test8/OrarImplTest.java,v 1.1 2018/08/08 04:54:33 cbar Exp $
 */

package com.ssn.ssijs.tests.orar;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author <a href="mailto:bario@ssi-schaefer-noell.com">bario</a>
 * @version $Revision: 1.1 $, $Date: 2018/08/08 04:54:33 $, $Author: cbar $
 */

public class OrarImplTest {
  Orar orar = new OrarImpl();

  public void setUp() {
    orar.addLine("Popescu Ion  ,1(7:30-11:30),1(13:00-14:00)");
    orar.addLine("Ionescu Gheo, 2(8:00-11:00), 4!(14:00-16:00)");
    orar.addLine("Ghita, 2(09:00-12:00), 4!(13:00-14:00), 3(*), 5!(*)");
  }

  @Test
  public void testLuni() {
    setUp();

    assertEquals(true, orar.allAvailableNextHour(1, 8));
    assertEquals(true, orar.allAvailableNextHour(1, 9));
    assertEquals(true, orar.allAvailableNextHour(1, 10));
    assertEquals(false, orar.allAvailableNextHour(1, 11));
    assertEquals(false, orar.allAvailableNextHour(1, 12));
    assertEquals(true, orar.allAvailableNextHour(1, 13));
    assertEquals(false, orar.allAvailableNextHour(1, 14));
    assertEquals(false, orar.allAvailableNextHour(1, 15));
    assertEquals(false, orar.allAvailableNextHour(1, 16));
    assertEquals(false, orar.allAvailableNextHour(1, 17));
    assertEquals(false, orar.allAvailableNextHour(1, 18));
  }

  @Test
  public void testMarti() {
    setUp();

    assertEquals(false, orar.allAvailableNextHour(2, 8));
    assertEquals(true, orar.allAvailableNextHour(2, 9));
    assertEquals(true, orar.allAvailableNextHour(2, 10));
    assertEquals(false, orar.allAvailableNextHour(2, 11));
    assertEquals(false, orar.allAvailableNextHour(2, 12));
    assertEquals(false, orar.allAvailableNextHour(2, 13));
    assertEquals(false, orar.allAvailableNextHour(2, 14));
    assertEquals(false, orar.allAvailableNextHour(2, 15));
    assertEquals(false, orar.allAvailableNextHour(2, 16));
    assertEquals(false, orar.allAvailableNextHour(2, 17));
    assertEquals(false, orar.allAvailableNextHour(2, 18));
  }

  @Test
  public void testMiercuri() {
    setUp();

    assertEquals(true, orar.allAvailableNextHour(3, 8));
    assertEquals(true, orar.allAvailableNextHour(3, 9));
    assertEquals(true, orar.allAvailableNextHour(3, 10));
    assertEquals(true, orar.allAvailableNextHour(3, 11));
    assertEquals(true, orar.allAvailableNextHour(3, 12));
    assertEquals(true, orar.allAvailableNextHour(3, 13));
    assertEquals(true, orar.allAvailableNextHour(3, 14));
    assertEquals(true, orar.allAvailableNextHour(3, 15));
    assertEquals(true, orar.allAvailableNextHour(3, 16));
    assertEquals(true, orar.allAvailableNextHour(3, 17));
    assertEquals(true, orar.allAvailableNextHour(3, 18));
  }

  @Test
  public void testJoi() {
    setUp();

    assertEquals(true, orar.allAvailableNextHour(4, 8));
    assertEquals(true, orar.allAvailableNextHour(4, 9));
    assertEquals(true, orar.allAvailableNextHour(4, 10));
    assertEquals(true, orar.allAvailableNextHour(4, 11));
    assertEquals(true, orar.allAvailableNextHour(4, 12));
    assertEquals(false, orar.allAvailableNextHour(4, 13));
    assertEquals(false, orar.allAvailableNextHour(4, 14));
    assertEquals(false, orar.allAvailableNextHour(4, 15));
    assertEquals(true, orar.allAvailableNextHour(4, 16));
    assertEquals(true, orar.allAvailableNextHour(4, 17));
    assertEquals(true, orar.allAvailableNextHour(4, 18));
  }

  @Test
  public void testVineri() {
    setUp();

    assertEquals(false, orar.allAvailableNextHour(5, 8));
    assertEquals(false, orar.allAvailableNextHour(5, 9));
    assertEquals(false, orar.allAvailableNextHour(5, 10));
    assertEquals(false, orar.allAvailableNextHour(5, 11));
    assertEquals(false, orar.allAvailableNextHour(5, 12));
    assertEquals(false, orar.allAvailableNextHour(5, 13));
    assertEquals(false, orar.allAvailableNextHour(5, 14));
    assertEquals(false, orar.allAvailableNextHour(5, 15));
    assertEquals(false, orar.allAvailableNextHour(5, 16));
    assertEquals(false, orar.allAvailableNextHour(5, 17));
    assertEquals(false, orar.allAvailableNextHour(5, 18));
  }
}
