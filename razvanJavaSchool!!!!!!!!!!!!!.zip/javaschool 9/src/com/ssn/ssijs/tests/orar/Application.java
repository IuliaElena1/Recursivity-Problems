/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Application {
  private Orar orar = new OrarImpl();
  private HTMLGenerator generator = new HTMLGenerator();

  public static void main(String[] args) throws IOException {
    Application main = new Application();
    main.readFile();
    main.generateHTML();
    main.showIntervals();
  }

  private void showIntervals() {
    for (Day day : Day.values()) {
      int startInterval = -1;
      int dayNr = day.ordinal() + 1;
      System.out.print(day + ": ");

      for (int hour = OrarImpl.START_HOUR; hour < OrarImpl.STOP_HOUR; hour++) {
        if (orar.allAvailableNextHour(dayNr, hour)) {
          if (startInterval == -1) {
            startInterval = hour;
          }
        } else {
          if (startInterval != -1) {
            System.out.print(startInterval + "-" + hour + ",");
            startInterval = -1;
          }
        }
      }

      if (startInterval != -1) {
        System.out.print(startInterval + "-" + OrarImpl.STOP_HOUR);
      }

      System.out.println();
    }
  }

  private void generateHTML() throws IOException {
    generator.generate(orar);
  }

  private void readFile() throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("orar.txt")));

    while (true) {
      String s = br.readLine();
      if (s == null) {
        break;
      }

      orar.addLine(s);
    }

    br.close();

  }
}
