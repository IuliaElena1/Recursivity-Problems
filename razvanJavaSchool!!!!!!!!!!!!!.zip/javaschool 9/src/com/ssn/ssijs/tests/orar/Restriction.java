/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Restriction {

  private int start;
  private int stop;
  private Day day;
  private boolean availability;

  // 1(10:00-13:00)
  public Restriction(String text) {
    char ch = text.charAt(0); //bagi cifra zilei intr-un caracter 
    this.day = Day.getDayFromChar(ch);
    this.availability = !text.contains("!");

    int startHour = OrarImpl.START_HOUR;
    int startMinute = 0;
    int stopHour = OrarImpl.STOP_HOUR;
    int stopMinute = 0;

    if (!text.contains("*")) {
      String[] splits = text.split("[()\\-:]+");

      startHour = Integer.parseInt(splits[1]);
      startMinute = Integer.parseInt(splits[2]);
      stopHour = Integer.parseInt(splits[3]);
      stopMinute = Integer.parseInt(splits[4]);
    }

    if (availability) {
      start = startMinute > 0 ? startHour + 1 : startHour;
      stop = stopHour;
    } else {
      start = startHour;
      stop = stopMinute > 0 ? stopHour + 1 : stopHour;
    }
  }

  @Override
  public String toString() {
    return "" + (this.day.ordinal() + 1) + this.availability + start + stop;
  }

  public Day getDay() {
    return this.day;
  }

  public boolean allowsPresenceNextHour(int from) {
    if (availability) {
      return start <= from && stop > from;
    } else {
      return start > from || stop <= from;
    }
  }
}
