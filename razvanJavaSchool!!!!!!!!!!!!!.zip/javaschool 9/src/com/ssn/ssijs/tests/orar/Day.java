/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public enum Day {
    LUNI, MARTI, MIERCURI, JOI, VINERI;

  public static Day getDayFromChar(char ch) {
    return Day.values()[Integer.parseInt("" + ch) - 1];
  }

}
