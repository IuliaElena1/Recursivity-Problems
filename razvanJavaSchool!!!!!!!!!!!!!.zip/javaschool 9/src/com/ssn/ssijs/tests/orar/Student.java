/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Student {
  private String name;
  private Map<Day, List<Restriction>> restrictions = new HashMap<>();

  public Student(String line) {
    String[] splits = line.split(",");
    this.name = splits[0].trim();

    for (int i = 1; i < splits.length; i++) {
      addRestriction(splits[i].trim());
    }
  }

  private void addRestriction(String text) {
    Restriction restriction = new Restriction(text);
    Day day = restriction.getDay();

    List<Restriction> restrictionsForDay = restrictions.get(day); //am creat o lista goala de srestrictii dupa day ex 1(  ) , 2(  ) 
    if (restrictionsForDay == null) { //daca lista este goala creem  un array list de restrictions
      restrictionsForDay = new ArrayList<Restriction>();
      restrictions.put(day, restrictionsForDay);
    }
    restrictionsForDay.add(restriction);
  }

  public boolean isAvailableNextHour(int day, int from) {
    Day dayEnum = Day.values()[day - 1];

    List<Restriction> restrictionsForDay = restrictions.get(dayEnum);
    if (restrictionsForDay == null) {
      return true;
    }

    for (Restriction restriction : restrictionsForDay) {
      if (restriction.allowsPresenceNextHour(from)) {
        return true;
      }
    }

    return false;
  }
}
