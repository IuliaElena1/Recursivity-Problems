/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class RestrictionTest {

  @Test
  public void test1() {
    Restriction r = new Restriction("1(10:00-13:00)");
    assertEquals("1true1013", r.toString());
  }

  @Test
  public void test11() {
    Restriction r = new Restriction("1(10:30-13:30)");
    assertEquals("1true1113", r.toString());
  }

  @Test
  public void test12() {
    Restriction r = new Restriction("1!(10:30-13:30)");
    assertEquals("1false1014", r.toString());
  }

  @Test
  public void test2() {
    Restriction r = new Restriction("2!(10:00-13:00)");
    assertEquals("2false1013", r.toString());
  }

  @Test
  public void test3() {
    Restriction r = new Restriction("2(*)");
    assertEquals("2true" + OrarImpl.START_HOUR + OrarImpl.STOP_HOUR, r.toString());
  }

  @Test
  public void test4() {
    Restriction r = new Restriction("2!(*)");
    assertEquals("2false" + OrarImpl.START_HOUR + OrarImpl.STOP_HOUR, r.toString());
  }

  @Test
  public void test5() {
    Restriction r = new Restriction("3(*)");
    assertEquals("3true" + OrarImpl.START_HOUR + OrarImpl.STOP_HOUR, r.toString());
    assertEquals(true, r.allowsPresenceNextHour(8));
  }
}
