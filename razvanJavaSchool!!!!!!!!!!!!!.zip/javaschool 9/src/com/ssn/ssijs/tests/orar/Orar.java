/*
 * Copyright (c) 2015 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cbar/iba_test8/src/com/ssn/ssijs/tests/orar/Orar.java,v 1.2 2018/08/08 13:13:59 cbar Exp $
 */

package com.ssn.ssijs.tests.orar;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: 1.2 $, $Date: 2018/08/08 13:13:59 $, $Author:  $
 */

public interface Orar {
  public void addLine(String line);

  public boolean allAvailableNextHour(int day, int from);
}
