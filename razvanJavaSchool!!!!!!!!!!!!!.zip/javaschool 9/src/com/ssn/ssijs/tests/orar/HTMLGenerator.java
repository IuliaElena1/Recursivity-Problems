/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class HTMLGenerator {
  public void generate(Orar orar) throws FileNotFoundException {
    PrintWriter pw = new PrintWriter(new File("output.html"));

    pw.println("<TABLE border='1'");

    pw.println("<TR>");
    pw.println("<TH>" + "" + "</TH>");

    for (Day day : Day.values()) {
      pw.println("<TH>" + day + "</TH>");
    }

    pw.println("</TR>");

    for (int hour = OrarImpl.START_HOUR; hour < OrarImpl.STOP_HOUR; hour++) {
      pw.println("<TR>");
      pw.println("<TD>" + hour + "-" + (hour + 1) + "</TD>");

      for (int day = 1; day <= Day.values().length; day++) {
        pw.println("<TD>" + (orar.allAvailableNextHour(day, hour) ? "X" : " ") + "</TD>");
      }
      pw.println("</TR>");
    }

    pw.println("</TABLE>");

    pw.close();
  }
}
