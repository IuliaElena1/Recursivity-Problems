/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

import java.util.ArrayList;
import java.util.List;

public class OrarImpl implements Orar {

  public static final int START_HOUR = 8;
  public static final int STOP_HOUR = 19;
  private List<Student> students = new ArrayList<Student>();

  @Override
  public void addLine(String line) {
    students.add(new Student(line));
  }

  @Override
  public boolean allAvailableNextHour(int day, int from) {
    for (Student student : students) {
      if (!student.isAvailableNextHour(day, from)) {
        return false;
      }
    }
    return true;
  }

}
