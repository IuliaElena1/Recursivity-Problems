/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.orar;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class IntervalBuilder {
  private int start = 0;
  private int stop = 0;

  public void addToInterval(int hour) {
    if (start == 0) {
      start = hour;
    }

    stop = hour + 1;
  }

  public void showIfAnyAndResetInterval() {
    if (start != 0) {
      System.out.print(start + "-" + stop + ",");
    }
    start = 0;
  }

}
