/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.combinations;

import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Main {
  /**
   * ("abc", 1) -> {a, b, c} 
   * ("abc", 2) -> {ab, ac, bc} 
   * ("abc", 3) -> {abc} 
   */
  public static List<String> getCombinations(String s, int k) {
    return null;
  }
}
