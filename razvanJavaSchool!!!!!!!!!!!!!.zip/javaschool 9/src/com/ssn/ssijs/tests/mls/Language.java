/*
 * Copyright (c) 2017 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cbar/iba_test12/src/com/ssn/ssijs/iba/test12/Language.java,v 1.1 2018/08/29 12:06:33 cbar Exp $
 */

package com.ssn.ssijs.tests.mls;

public enum Language {
    RO, EN
}
