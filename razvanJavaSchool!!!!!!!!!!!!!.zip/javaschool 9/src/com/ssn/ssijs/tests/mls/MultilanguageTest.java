/*
 * Copyright (c) 2017 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cbar/iba_test12/src/com/ssn/ssijs/iba/test12/MultilanguageTest.java,v 1.1 2018/08/29 12:22:42 cveina Exp $
 */

package com.ssn.ssijs.tests.mls;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: 1.1 $, $Date: 2018/08/29 12:22:42 $, $Author: cveina $
 */

public class MultilanguageTest {

  private Localisation loc;

  @Before
  public void setUp() {
    loc = new LocalisationImpl();
  }

  @Test
  public void testNoInit() {
    loc.setLanguage(Language.EN);
    assertFalse(loc.getMessage("/message/changeLang").startsWith("!"));
  }

  @Test
  public void testGetMessageNotFound() {
    loc.setLanguage(Language.EN);
    assertTrue(loc.getMessage("xxx").startsWith("!"));
  }

  @Test
  public void testGetMessage() {
    loc.setLanguage(Language.EN);
    assertTrue(loc.getMessage("/message/changeLang").equals("Change language"));
  }

  @Test
  public void testGetMessageWithParams() {
    loc.setLanguage(Language.RO);
    assertTrue(loc.getMessage("/message/params", new Object[] { "XXX", 123 }).equals("Limba curenta este XXX si valoarea curenta din enumeration-ul Language este 123"));
  }

  @Test
  public void testChangeLanguage() {
    loc.setLanguage(Language.EN);
    assertTrue(loc.getMessage("/message/changeLang").equals("Change language"));
    loc.setLanguage(Language.RO);
    assertTrue(loc.getMessage("/message/changeLang").equals("Schimba limba"));
    loc.setLanguage(Language.EN);
    assertTrue(loc.getMessage("/message/changeLang").equals("Change language"));
  }
}
