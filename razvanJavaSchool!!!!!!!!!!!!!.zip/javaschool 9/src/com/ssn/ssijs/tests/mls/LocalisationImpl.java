/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.mls;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class LocalisationImpl implements Localisation {
  private Map<Language, Properties> languages = new HashMap<>();
  private Language currentLanguage;

  public LocalisationImpl() {
    setLanguage(Language.EN);
  }

  @Override
  public void setLanguage(Language lang) {
    currentLanguage = lang;
    loadFileIfNecessarry();
  }

  private void loadFileIfNecessarry() {
    if (languages.containsKey(currentLanguage)) {
      return;
    }

    Properties prop = new Properties();
    String fileName = "message_" + currentLanguage.name().toLowerCase() + ".txt";
    try {
      prop.load(new FileInputStream(new File(fileName)));
      languages.put(currentLanguage, prop);
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  @Override
  public String getMessage(String key) {
    Properties properties = languages.get(currentLanguage);
    return properties.getProperty(key, "!" + key);
  }

  @Override
  public String getMessage(String key, Object[] params) {
    Properties properties = languages.get(currentLanguage);
    String message = properties.getProperty(key, "!" + key);

    if (params == null) {
      return message;
    }

    for (int i = 0; i < params.length; i++) {
      message = message.replace("{" + i + "}", params[i].toString());
    }

    return message;
  }

}
