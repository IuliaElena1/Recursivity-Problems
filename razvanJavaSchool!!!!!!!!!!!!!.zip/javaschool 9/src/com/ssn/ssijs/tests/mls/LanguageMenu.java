/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.tests.mls;

import java.util.Scanner;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class LanguageMenu {
  private Scanner scanner = new Scanner(System.in);
  Localisation mls = new LocalisationImpl();

  public static void main(String[] args) {
    new LanguageMenu().run();
  }

  private void run() {
    loop: while (true) {
      showMenu();
      String input = scanner.nextLine();

      switch (input) {
        case "1":
          changeLanguage();
          break;
        case "0":
          break loop;
      }
    }

    scanner.close();
  }

  private void changeLanguage() {
    while (true) {
      showChangeLangMenu();
      String input = scanner.nextLine();

      if ("0".equals(input)) {
        return;
      }

      try {
        int langId = Integer.parseInt(input);
        Language lang = Language.values()[langId - 1];
        mls.setLanguage(lang);

        String langString = "";
        switch (lang) {
          case EN:
            langString = mls.getMessage("/message/engleza");
            break;
          case RO:
            langString = mls.getMessage("/message/romana");
            break;
        }

        System.out.println(mls.getMessage("/message/params", //
          new Object[] { langString, lang }));
      } catch (NumberFormatException e) {
        System.out.println(mls.getMessage("/message/invalidLang"));
      }
    }
  }

  private void showChangeLangMenu() {
    for (Language lang : Language.values()) {
      System.out.println((lang.ordinal() + 1) + ". " + mls.getMessage("/message/" + lang.name().toLowerCase()));
    }
    System.out.println("0. " + mls.getMessage("/message/back"));
  }

  private void showMenu() {
    System.out.println("1. " + mls.getMessage("/message/changeLang"));
    System.out.println("0. " + mls.getMessage("/message/exit"));
  }

}
