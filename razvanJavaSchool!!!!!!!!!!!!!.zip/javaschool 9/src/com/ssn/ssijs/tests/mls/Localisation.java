
package com.ssn.ssijs.tests.mls;

public interface Localisation {

  public String getMessage(String key);

  public String getMessage(String key, Object[] params);

  public void setLanguage(Language lang);

}
