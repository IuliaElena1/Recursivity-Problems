/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.enums;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */
public enum Day {
    LU("Luni"), MA("Marti"), MI("Miercuri"), JO("Joi"), //
    VI("Weekend"), SA("Weekend"), DU("Weekend");

  private String message;

  Day(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }

  @Override
  public String toString() {
    return super.toString();
  }

}
