/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.enums;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DaysThingWithEnum {
  public static void main(String[] args) {
    dayThing(1);

    dayThing2(Day.LU);

    Day day = Day.valueOf("LU");
    Day[] values = Day.values();
    System.out.println(Day.LU.compareTo(Day.MA));
    System.out.println(Day.MA.compareTo(Day.LU));
    System.out.println(Day.LU.compareTo(Day.LU));
    System.out.println(Day.LU.equals(Day.LU));
    System.out.println(Day.MA.equals(Day.LU));
    System.out.println(Day.DU.name());
    System.out.println(Day.DU.ordinal());
    System.out.println(Day.LU.ordinal());
    System.out.println(Day.LU.toString());
  }

  private static void dayThing(int day) {
    Day[] values = Day.values();
    System.out.println(Arrays.toString(values));
    System.out.println(values[day - 1]);
  }

  private static void dayThing2(Day day) {
    System.out.println(day.getMessage());
  }

}
