/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.enums;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DaysThing {
  public static void main(String[] args) {
    showDayInfo(5);
  }

  private static void showDayInfo(int day) {
    switch (day) {
      case 1:
        System.out.println("Lu");
        break;
      case 2:
        System.out.println("Ma");
        break;
      case 3:
        System.out.println("Mi");
        break;
      case 4:
        System.out.println("Jo");
        break;
      case 5:
        System.out.println("Vi");
        break;
      case 6:
        System.out.println("Sa");
        break;
      case 7:
        System.out.println("Du");
        break;
      default:
        System.out.println("Invalid day");
    }
  }
}
