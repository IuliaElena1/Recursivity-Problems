/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.reflection;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ReflectionThing {
  public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
    try {
      Class<?> clazz = Class.forName("1com.ssn.ssijs.javaschool.reflection.DataCreatorExample");
      DataCreator dataCreator = (DataCreator) clazz.newInstance();
      dataCreator.createInitialData(new Database());
    } catch (Exception e) {
      System.out.println("Initialisation class not found");
    }
  }
}
