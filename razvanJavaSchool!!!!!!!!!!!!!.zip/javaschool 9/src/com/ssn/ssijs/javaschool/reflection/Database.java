/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.reflection;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Database implements DatabaseOperations {

  @Override
  public void addIndivisibleDrug(String barcode, String brand, String details, int width, int height, int length) {
    System.out.println("addIndiv");
  }

  @Override
  public void addDivisibleDrug(String barcode, String brand, String details, int width, int height, int length, int numberOfSubdivisions) {
    System.out.println("addDiv");
  }

  @Override
  public void addStock(String barcode, String drawerId, int numberOfBoxes) {
    System.out.println("addStock");
  }

}
