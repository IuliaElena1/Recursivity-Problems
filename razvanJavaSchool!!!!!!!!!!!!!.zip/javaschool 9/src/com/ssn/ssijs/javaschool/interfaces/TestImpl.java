/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.interfaces;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestImpl implements Test {

  @Override
  public int add(int a, int b) {
    return a + b;
  }

  @Override
  public int div(int a, int b) {
    if (b == 0) {
      return -1;
    }
    return a / b;
  }

}
