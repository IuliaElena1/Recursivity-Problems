/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.interfaces;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TestTest {

  @Test
  public void test1() {
    com.ssn.ssijs.javaschool.interfaces.Test test = new TestImpl();
    assertEquals(12, test.add(5, 7));
  }

  @Test
  public void test2() {
    com.ssn.ssijs.javaschool.interfaces.Test test = new TestImpl();
    assertEquals(0, test.div(5, 7));
  }

  @Test
  public void test3() {
    com.ssn.ssijs.javaschool.interfaces.Test test = new TestImpl();
    assertEquals(-1, test.div(5, 0));
  }

}
