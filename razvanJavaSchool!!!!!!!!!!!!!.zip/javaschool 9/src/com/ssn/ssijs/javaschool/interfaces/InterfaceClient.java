/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.interfaces;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class InterfaceClient {
  public static void main(String[] args) {
    MyInterface[] mi = { new MyInterfaceImpl(), new MyInterfaceImpl2(), new MyInterfaceImpl3() };

    for (MyInterface m : mi) {
      System.out.println(m.getClass().getName());
      System.out.println(m.sum(5, 6));
      m.metodaMeaDefault();
      MyInterface.metodaMeaStatica();
    }

    MyInterfaceImpl a = new MyInterfaceImpl();
    a.sum();
    a.sum(1, 1);
    MyInterface b = new MyInterfaceImpl();
    b.sum(1, 1);
    Interface2 c = new MyInterfaceImpl();
    c.sum();
    c.sum(1, 1);

    MyInterface d = new MyInterfaceImpl();
    d.sum(1, 1);
    if (d instanceof MyInterfaceImpl) {
      MyInterfaceImpl e = (MyInterfaceImpl) d;
      e.sum();
    }

    System.out.println(MyInterface.N);
    System.out.println(Interface2.N);
  }
}

/*
Se considera o armata compusa din urmatoarele entitati:
1. Soldati, caracterizati prin nume
2. Tancuri, caracterizate prin nume, numar de proiectile, numar de gloante
3. Nave de razboi, caracterizate prin nume, numar de tunuri, numar de rachete   
4. Submarine, caracterizate prin nume, numar de torpile
5. Avioane de lupta, caracterizate prin nume, numar de rachete, numar de bombe

Sa se construiasca o armata cu cel putin cate doua elemente de fiecare tip, 
sa se afiseze toate entitatile din armata ordonate dupa puterea de foc(firepower), si de 
asemenea sa se calculeze puterea totala de foc stiind ca:
 - soldatii au firepower = 1
 - tancurile au firepower = nrProiectile * 50 + numarDeGloante
 - navele de razboi au firepower = nrTunuri * 100 + rachete * 1000 
 - submarinele au firepower = nrTorpile * 500
 - avioanele de lupta au firepower = nr de rachete * 1000 + nr de bombe * 2000
 
sa se creeze o metoda care sa permita o "confruntare" intre 
doua astfel de armate, astfel incat dupa o confruntare, o parte din fiecare 
armata sa dispara iar aceasta metoda sa poata fi apelata de mai multe ori pana
cand una din armate dispare total. 

la fiecare pas se va afisa starea celor doua armate

o propunere de mod de confruntare este:
se confrunta pe rand soldati cu soldati, tancuri cu tancuri, etc...
de ex. pentru soldati vs soldati, armata 1 are 50, armata 2 are 30
se foloseste metoda Math.random() care genereaza un nr aleator intre 
0 inclusiv si 1 exclusiv [0,1) 
dupa confruntare:
   arm 1 ramane cu 50 - 30 * Math.random()
   arm 2 ramane cu 30 - 50 * Math.random()

*/