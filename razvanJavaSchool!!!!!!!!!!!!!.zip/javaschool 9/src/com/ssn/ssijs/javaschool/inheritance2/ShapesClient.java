/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance2;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ShapesClient {
  public static void main(String[] args) {
    Rectangle[] rectangles = { new Rectangle("red", 10, 20), new Rectangle("blue", 5, 4) };

    for (Rectangle r : rectangles) {
      r.showColor();
      System.out.println(r.getArea());
    }

    Square[] squares = { new Square("red", 10), new Square("blue", 5) };

    for (Square s : squares) {
      s.showColor();
      System.out.println(s.getArea());
    }
  }
}
