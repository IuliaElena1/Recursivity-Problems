/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance2;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Square {
  private String color;
  private int side;

  public Square(String color, int side) {
    super();
    this.color = color;
    this.side = side;
  }

  public void showColor() {
    System.out.println(color);
  }

  public int getArea() {
    return side * side;
  }
}
