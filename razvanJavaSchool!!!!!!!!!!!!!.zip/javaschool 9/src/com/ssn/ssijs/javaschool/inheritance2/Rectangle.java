/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance2;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Rectangle {
  private String color;
  private int width;
  private int length;

  public Rectangle(String color, int width, int length) {
    super();
    this.color = color;
    this.width = width;
    this.length = length;
  }

  public void showColor() {
    System.out.println(color);
  }

  public int getArea() {
    return width * length;
  }
}
