/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

// 10010 = 18
// 10101 = 21
// 00100 = 4
// 01100 = 12
// 01110 = 14
// 11110 = 30
// 68421 
// 1

// 7 =   0111
// 10 =  1010
// 11 =  1011
// 12 =  1100
// 13 =  1101
// 14 =  1110
// 15 =  1111
// 16 = 10000
//  11111111
//  1,2,4,8,16,32,64,128,256,512,1024

public class Person {
  int age;
  boolean b;
  final static int NR_OCHI = 2;

  public static void main(String[] args) {
    byte b = (byte) 0x80;
    byte b1 = (byte) 0b01010101;
    System.out.println(b);
    System.out.println(b1);

    int variabilaLocala = (int) 1L;
    String s = "Hello world";
    s = null;
    System.out.println(variabilaLocala);
    //nrOchi = 3;
    metodaMea(5);
    metodaMea(3);

    double d = 4.5f;
    float f = 4.5f;

    char ch = 'A';
    ch++;
    System.out.println(ch);

    System.out.println("\\ \\ \" \" \' \' \n \\ \u0108");
  }

  private static void metodaMea(int n) {
    int x = 7_777;
  }
}
