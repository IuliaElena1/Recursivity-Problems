/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.numbers;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class NumbersThing {
  public static void main(String[] args) {
    int nr = 7;
    //Integer nr2 = 5;
    Integer nr2 = new Integer(5);
    List<Integer> list = new ArrayList<Integer>();

    Long l = new Long(4);

    Integer nr3 = 5; // new Integer(5); autoboxing
    int nr4 = nr2; // nr2.intValue();  unboxing

    //String x = "123";
    int n = Integer.parseInt("123");
  }

  public Integer find(int[] arr, int n) {
    for (int i = 0; i < arr.length; i++) {
      if (arr[i] == n) {
        return i;
      }
    }
    return null;
  }
}
