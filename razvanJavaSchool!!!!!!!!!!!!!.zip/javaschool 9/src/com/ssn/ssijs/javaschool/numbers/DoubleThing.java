/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.numbers;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DoubleThing {
  public static void main(String[] args) {
    double x = 0;

    for (int i = 1; i <= 10; i++) {
      x += 0.1;
      System.out.println(x);
    }

    System.out.println(x);
  }
}
