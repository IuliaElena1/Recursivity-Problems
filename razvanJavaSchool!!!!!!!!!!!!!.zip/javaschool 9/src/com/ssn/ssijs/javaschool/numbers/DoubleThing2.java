/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.numbers;

import java.math.BigDecimal;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DoubleThing2 {
  public static void main(String[] args) {
    BigDecimal x = new BigDecimal(0);

    for (int i = 1; i <= 10; i++) {
      x = x.add(new BigDecimal(0.1));
    }

    System.out.println(x.floatValue());
  }
}
