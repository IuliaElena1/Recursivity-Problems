/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.specialclasses;

import com.ssn.ssijs.javaschool.inheritance.Rectangle;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ObjectThing {
  public static void main(String[] args) {
    Object obj = new Object();
    System.out.println(obj.getClass().getName());
    System.out.println(obj.getClass().isAssignableFrom(Rectangle.class));

    Rectangle r = new Rectangle("", 2, 1);
    Rectangle r2 = new Rectangle("", 1, 2);
    System.out.println(r.getClass().isAssignableFrom(Object.class));

    System.out.println(obj.toString());

    r.m(obj);
    r.m("123");

    System.out.println(r);

    System.out.println(r.equals(r2));

  }
}
