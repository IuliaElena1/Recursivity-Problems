/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Operators {
  public static void main(String[] args) {
    int x = 10;
    x++;
    System.out.println(x);
    System.out.println(x++);
    System.out.println(++x);
    System.out.println(-x);
    System.out.println(-(-x));

    System.out.println(x % 2 == 0);
    System.out.println(x % 2 == 1);

    System.out.println((5 + 3) * 2);

    // 110.... 0100  1010....
    // 000.... 
    System.out.println(8 << 1);
    System.out.println((byte) -8 >>> 1);
    System.out.println((byte) -8 >> 2);

    System.out.println(5 > 3);
    System.out.println(5 < 3);
    System.out.println(5 != 3);
    System.out.println(5 == 3);

    int n = 5;
    System.out.println(n > 4 || n < 11);

    System.out.println(0b00011100 & 0b00011111);
    System.out.println(n > 4 && n < 11);

    /*
     * AND   0     1  0=false 1=true
     *   0   0     0
     *   1   0     1
     * OR    0     1
     *   0   0     1
     *   1   1     1   
     * XOR   0     1
     *   0   0     1
     *   1   1     0   
     */
    n = 5;
    System.out.println(n > 4 || metodaMea() == true);

    System.out.println(n == 5 ? ("n e 5" + n) : "n nu e 5");

    n = n + 2;
    n += 2;
    String a = "abc";
    a += "d";
    System.out.println(a);
  }

  private static boolean metodaMea() {
    System.out.println("abc");
    return true;
  }
}
