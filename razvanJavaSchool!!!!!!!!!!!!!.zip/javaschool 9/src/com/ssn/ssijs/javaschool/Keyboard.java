/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

import java.util.Scanner;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Keyboard {
  public static void main(String[] args) {
    System.out.println(args[0]);

    Scanner in = new Scanner(System.in);
    String s = in.nextLine();
    System.out.println(s);
    System.out.println(s.charAt(0));
    System.out.println(s.substring(1));
    int n = Integer.parseInt("123");
    System.out.println(n);
    in.close();
  }
}
