/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.composition;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class CarClient {
  public static void main(String[] args) {
    Car c = new Car();
    Engine e = new Engine();
    c.setEngine(e);

  }
}
