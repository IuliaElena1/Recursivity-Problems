/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SwitchThing {
  public static void main(String[] args) {
    int dayOfWeek = 12;
    double d;
    String s;

    switch (dayOfWeek) {
      case 1:
        System.out.println("Luni");
        break;
      case 2:
        System.out.println("Marti");
        break;
      case 3:
        System.out.println("Miercuri");
        break;
      case 4:
        System.out.println("Joi");
        break;
      case 5:
        System.out.println("Vineri");
        break;
      default:
        System.out.println("Weekend");
    }

  }
}
