/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class FilesThing {
  public static void main(String[] args) throws IOException {
    writeFile("test.txt");
    readFile("test.txt");
  }

  private static void readFile(String fileName) throws IOException {
    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));

    while (true) {
      String s = br.readLine();
      if (s == null) {
        break;
      }

      System.out.println(s);
    }

    br.close();
  }

  private static void writeFile(String fileName) throws FileNotFoundException {
    PrintWriter pw = new PrintWriter(new File(fileName));

    pw.println("asd");
    pw.println("qwe");
    pw.println("zxc");
    //pw.println("z\nx\nc"); // diferenta Linux / Windows \n \n\r
    String enter = System.lineSeparator();
    pw.println("z" + enter + "x" + enter + "c");

    pw.close();
  }
}
