
package com.ssn.ssijs.javaschool.things;

public class GC {
  public static void main(String[] args) {
    String s1 = new String("abc");
    String s3 = method(); //
    s1 = s3;
    for (int i = 0; i < 3; i++) {
      String s4 = new String("" + i);
      System.out.println(s4);
    }
    s3 = null;
  }

  private static String method() {
    String s2 = new String("x");
    s2 = new String("y");
    return s2;
  }
}