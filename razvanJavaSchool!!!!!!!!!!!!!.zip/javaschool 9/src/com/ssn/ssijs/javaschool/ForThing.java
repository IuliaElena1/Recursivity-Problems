/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ForThing {
  public static void main(String[] args) {
    for (int i = 1, j = 1; i < 11; i++, j += 2) {
      System.out.println(i);
      System.out.println(j);
    }

    label: for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (j == 1) {
          break label;
        }

        System.out.println(i + ", " + j);
      }
    }

    int[] x = { 5, 7, 3, 67, 9, 9 };

    for (int i = 0; i < x.length; i++) {
      System.out.print(x[i]);
    }

    for (int element : x) {
      System.out.print(element);
    }

    //    for (;;) {
    //      
    //    }

    metoda(x);
    int y = metoda2();
  }

  private static int metoda2() {
    for (int i = 1; i < 5; i++) {
      if (i == 2) {
        return i;
      }
    }
    return 0;
  }

  private static void metoda(int[] x) {
    for (int i = 0; i < x.length; i++) {
      if (i == 2) {
        break;
      }
      System.out.print(x[i]);
    }

    System.out.println("Logica");
  }

}
