/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class MapsThing {
  public static void main(String[] args) {
    Map<String, Integer> map = new HashMap<>();
    map.put("Ion", 30);
    map.put("Gheo", 40);
    map.put("Mircea", 20);

    System.out.println(map);

    System.out.println(map.get("Ion"));

    for (Entry<String, Integer> entry : map.entrySet()) {
      System.out.println(entry);
    }

    System.out.println(map.containsKey("Ion"));
    System.out.println(map.getOrDefault("qwe", 10));
    map.putIfAbsent("q", 100);
    map.put("Ion", 100);
    System.out.println(map);

    for (String s : map.keySet()) {
      System.out.println(s);
    }
  }
}
