/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.collections;

import java.util.HashSet;
import java.util.Set;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SetThing {
  public static void main(String[] args) {
    Set<String> set = new HashSet<>();
    set.add("asd");
    set.add("qwe");
    set.add("zxc");
    set.add("zxc");
    set.add("zxc");
    set.add(null);

    System.out.println(set);

    Set<Person> set2 = new HashSet<>();
    set2.add(new Person("asd"));
    set2.add(new Person("qwe"));
    set2.add(new Person("zxc"));

    System.out.println(set2);

    System.out.println(set2.contains(new Person("asd")));
  }
}
