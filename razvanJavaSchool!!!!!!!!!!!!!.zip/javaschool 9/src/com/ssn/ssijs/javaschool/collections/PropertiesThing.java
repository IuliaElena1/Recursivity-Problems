/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.collections;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class PropertiesThing {
  public static void main(String[] args) throws FileNotFoundException, IOException {
    Properties prop = new Properties();
    prop.load(new FileInputStream("test.ini"));

    System.out.println(prop.getProperty("qwe"));
    System.out.println(prop.getProperty("asd"));
    System.out.println(prop.getProperty("zxc"));

    System.out.println(prop);
  }
}
