/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ArraysThing2 {
  public static void main(String[] args) {
    List<String> list = new ArrayList<>();
    list.add("qwe");
    list.add("asd");
    list.add("zxc");

    Collections.sort(list); // TO BE CONTINUED...
    System.out.println(list);

    List<Person> list2 = new ArrayList<>();
    list2.add(new Person("mircea", 50));
    list2.add(new Person("gheo", 60));
    list2.add(new Person("ion", 30));

    Collections.sort(list2);
    System.out.println(list2);

    Comparator<Person> comparator = new Comparator<Person>() {
      @Override
      public int compare(Person o1, Person o2) {
        return o1.age - o2.age;
      }
    };

    Collections.sort(list2, comparator);
    Collections.sort(list2, new MyComparator());
    System.out.println(list2);

  }
}
