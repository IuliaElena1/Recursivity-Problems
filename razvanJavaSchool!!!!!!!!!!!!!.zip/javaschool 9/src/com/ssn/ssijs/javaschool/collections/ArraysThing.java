/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ArraysThing {
  public static void main(String[] args) {
    List<String> list = new ArrayList<>();
    list.add("qwe");
    list.add("asd");
    list.add("zxc");
    System.out.println(list.get(1));
    System.out.println(list.size());
    System.out.println(list.contains("qwe"));

    // java.util.ConcurrentModificationException
    //    for (String s : list) {
    //      if (s.equals("qwe")) {
    //        list.remove(s);
    //      }
    //    }

    // Solutia la ConcurrentModificationException
    Iterator<String> iterator = list.iterator();
    while (iterator.hasNext()) {
      String s = iterator.next();
      if (s.equals("qwe")) {
        iterator.remove();
      }
    }

    Collections.sort(list); // TO BE CONTINUED...
    System.out.println(list);

    List<Person> list2 = new ArrayList<>();
    list2.add(new Person("ion"));
    list2.add(new Person("gheo"));
    list2.add(new Person("mircea"));
    System.out.println(list2.get(1));
    System.out.println(list2.size());
    System.out.println(list2.contains(new Person("mircea")));
    System.out.println(list2.toArray());
    System.out.println(list2.remove(new Person("mircea")));
    System.out.println(list2.remove(0));
    list2.clear();
    list2.add(new Person("ion"));
    list2.add(new Person("gheo"));
    list2.add(new Person("mircea"));
    list2.set(0, new Person("mircea"));
    System.out.println(list2.indexOf(new Person("mircea")));

    System.out.println(list2);

  }
}
