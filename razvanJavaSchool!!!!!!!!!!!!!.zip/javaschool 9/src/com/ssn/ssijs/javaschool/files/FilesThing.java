/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.files;

import java.io.File;
import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class FilesThing {
  public static void main(String[] args) {
  /*  System.out.println(Arrays.toString(args));
    System.out.println(args[0]);
    System.out.println(args[1]);
    System.out.println(args[2]);*/
    //
    File folder = new File("."); // comentariu
    System.out.println(folder.exists());

    File[] files = folder.listFiles();

    for (File f : files) {
      System.out.println(f.getAbsolutePath() + "  " + f.isDirectory());
    }
  }
}
