/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/Soldat.java,v 1.1 2019/02/01 14:04:01 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:01 $, $Author: cpopa $
 */

public class Soldat extends Unit {
  static final int FIREPOWER = 1;

  public Soldat(String name) {
    super(name);
  }

  @Override
  int getFirepower() {
    if (!this.isAlive()) {
      return 0;
    }
    return FIREPOWER;
  }
}
