/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/Tanc.java,v 1.1 2019/02/01 14:04:01 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:01 $, $Author: cpopa $
 */

public class Tanc extends Unit {
  int nrProiectile;
  int nrGloante;

  public Tanc(String nume, int nrProiectile, int nrGloante) {
    super(nume);
    this.nrProiectile = nrProiectile;
    this.nrGloante = nrGloante;
  }

  @Override
  int getFirepower() {
    if (!this.isAlive()) {
      return 0;
    }
    return nrProiectile * 50 + nrGloante;
  }

}
