/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Army {
  private Unit[] units;
  private double morale;
  private String name;

  public Army(String name, Unit[] units, double morale) {
    super();
    this.name = name;
    this.units = units;
    this.morale = morale;
  }

  public int getArmyFP() {
    int result = 0;

    for (Unit u : units) {
      result += u.getFirepower();
    }

    return (int) (result * morale);
  }

  public void simulateDeath(double prob) {
    for (Unit unit : units) {
      if (Math.random() > prob) {
        unit.setAlive(false);
      }
    }
  }

  @Override
  public String toString() {
    return name + " [" + getArmyFP() + "]";
  }

  public void displayAlive() {
    System.out.print("Unitati in viata pentru " + name + ": ");
    for (Unit unit : units) {
      if (unit.isAlive()) {
        System.out.print(" " + unit.toString() + ",");
      }
    }
    System.out.println();
  }

  public Unit getUnitByName(String name) {
    for (Unit unit : units) {
      if (unit.hasName(name)) {
        return unit;
      }
    }
    return null;
  }
}
