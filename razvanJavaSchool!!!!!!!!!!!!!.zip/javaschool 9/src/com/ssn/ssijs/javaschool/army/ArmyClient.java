/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/General.java,v 1.1 2019/02/01 14:04:00 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:00 $, $Author: cpopa $
 */

public class ArmyClient {
  public static void main(String[] args) {
    Unit[] units1 = { new Soldat("Private Ryan"), new Soldat("Private Jenkins"), new Soldat("Privare Hicks"), new Soldat("Private Winter"), //
      new Tanc("Sherman", 4, 100), new Tanc("Abrams", 6, 300), new Tanc("Panzer", 5, 350), // 
      new NavaDeRazboi("Dallas", 15, 10), new NavaDeRazboi("Oklahoma", 30, 25), //
      new Submarin("Red October", 15), new Submarin("Nautilus", 23), new Submarin("Yellow", 10), //
      new Avion("Spitfire", 4, 2), new Avion("Pinto", 2, 1), new Avion("Papagal", 3, 3) };

    Unit[] units2 = { new Soldat("Private Ryan2"), new Soldat("Private Jenkins2"), new Soldat("Private Harris"), //
      new Tanc("Sherman2", 6, 100), new Tanc("Abrams2", 4, 300), // 
      new NavaDeRazboi("Dallas2", 30, 10), new NavaDeRazboi("Oklahoma2", 15, 25), new NavaDeRazboi("Kansas", 20, 30), //
      new Submarin("Red October2", 25), new Submarin("Nautilus2", 13), //
      new Avion("Spitfire2", 2, 2), new Avion("Pinto2", 4, 1), new Avion("Schmit", 3, 5) };

    Army army1 = new Army("Scorpionii rosii", units1, 5);
    Army army2 = new Army("Plaiesii maro", units2, 1);

    //Arrays.sort(armata1);
    ArmyClient p = new ArmyClient();
    //p.sort(units1);
    Army winner = p.getWinner(army1, army2);
    System.out.println("Castigatorul este: " + winner.toString());
    winner.displayAlive();

    Unit unit = army1.getUnitByName("private Ryan");
    System.out.println(unit.isAlive());
  }

  public Army getWinner(Army army1, Army army2) {
    while (true) {
      int army1FP = army1.getArmyFP();
      int army2FP = army2.getArmyFP();

      if (army1FP == 0) {
        return army2;
      }

      if (army2FP == 0) {
        return army1;
      }

      double totalFP = army1FP + army2FP;
      double procentA = army1FP / totalFP;
      double procentB = army2FP / totalFP;

      army1.simulateDeath(procentA);
      army2.simulateDeath(procentB);

      System.out.println(army1.toString() + " " + army2.toString());
    }
  }

}