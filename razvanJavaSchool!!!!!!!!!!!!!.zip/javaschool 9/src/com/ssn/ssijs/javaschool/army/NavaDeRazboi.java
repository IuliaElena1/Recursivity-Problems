/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/NavaDeRazboi.java,v 1.1 2019/02/01 14:04:01 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:01 $, $Author: cpopa $
 */

public class NavaDeRazboi extends Unit {
  int nrTunuri;
  int nrRachete;

  public NavaDeRazboi(String nume, int nrTunuri, int nrRachete) {
    super(nume);
    this.nrTunuri = nrTunuri;
    this.nrRachete = nrRachete;
  }

  @Override
  int getFirepower() {
    if (!this.isAlive()) {
      return 0;
    }
    return nrTunuri * 100 + nrRachete * 100;
  }

}
