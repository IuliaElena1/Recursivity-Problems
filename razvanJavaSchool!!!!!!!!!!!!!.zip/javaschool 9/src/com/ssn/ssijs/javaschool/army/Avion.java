/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/Avion.java,v 1.1 2019/02/01 14:04:00 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:00 $, $Author: cpopa $
 */

public class Avion extends Unit {
  int nrRachete;
  int nrBombe;

  public Avion(String nume, int nrRachete, int nrBombe) {
    super(nume);
    this.nrRachete = nrRachete;
    this.nrBombe = nrBombe;

  }

  @Override
  int getFirepower() {
    if (!this.isAlive()) {
      return 0;
    }
    return nrRachete * 1000 + nrBombe * 2000;
  }

}
