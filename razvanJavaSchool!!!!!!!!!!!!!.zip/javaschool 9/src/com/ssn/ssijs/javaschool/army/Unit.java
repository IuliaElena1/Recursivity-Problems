/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: /data/cvs/Scolarizare/cpopa/mpo_work/src/com/ssn/ssijs/mpo/work/Armata.java,v 1.1 2019/02/01 14:04:00 cpopa Exp $
 */

package com.ssn.ssijs.javaschool.army;

/**
 * @author <a href="mailto:mpopa@ssi-schaefer-noell.com">mpopa</a>
 * @version $Revision: 1.1 $, $Date: 2019/02/01 14:04:00 $, $Author: cpopa $
 */

public abstract class Unit implements Comparable<Unit> {
  private String nume;
  private boolean alive;

  public boolean isAlive() {
    return alive;
  }

  public void setAlive(boolean alive) {
    this.alive = alive;
  }

  @Override
  public int compareTo(Unit o) {

    if (this.getFirepower() > o.getFirepower()) {
      return 1;
    } else if (this.getFirepower() < o.getFirepower()) {
      return -1;
    } else {
      return 0;
    }
  }

  public Unit(String nume) {
    this.nume = nume;
    this.alive = true;
  }

  abstract int getFirepower();

  public boolean hasName(String name) {
    // return if name !=null ... name.equals("ABC");
    // return "ABC".equals(name);
    // return name.equals(this.nume);
    return this.nume.equalsIgnoreCase(name);
  }

  @Override
  public String toString() {
    return this.nume;
  }
}
