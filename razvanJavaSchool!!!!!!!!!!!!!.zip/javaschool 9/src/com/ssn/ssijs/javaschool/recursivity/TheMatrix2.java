/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TheMatrix2 {
  public static void main(String[] args) {
    int[][] matrix = { //
      { 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0 }, //
      { 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0 }, //
      { 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0 }, //
      { 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0 }, //
      { 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0 }, //
      { 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0 }, //
      { 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, //
      { 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0 }, //
      { 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0 }, //
      { 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0 }, //
      { 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0 }, //
    };

    fill(matrix, 4, 4);
    showMatrix(matrix);
    System.out.println();
    fill(matrix, 0, 0);
    showMatrix(matrix);
    System.out.println();
    fill(matrix, 10, 10);
    showMatrix(matrix);
  }

  private static void fill(int[][] matrix, int x, int y) {
    if (x < 0 || y < 0 || x >= matrix.length || y >= matrix[0].length) {
      return;
    }
    if (matrix[x][y] != 0) {
      return;
    }

    matrix[x][y] = 2;
    fill(matrix, x + 1, y);
    fill(matrix, x - 1, y);
    fill(matrix, x, y - 1);
    fill(matrix, x, y + 1);
  }

  private static void showMatrix(int[][] matrix) {
    for (int[] row : matrix) {
      System.out.println(Arrays.toString(row));
    }
  }
}
