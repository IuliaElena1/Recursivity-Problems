/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Simple {
  /**
   * f(0) = 1
   * f(n) = n * fact(n - 1)
   * @param n
   * @return
   */
  public int fact(int n) {
    if (n == 0) {
      return 1;
    }
    return n * fact(n - 1);
  }

  /**
   * Fibo:
   * f(0) = 0 
   * f(1) = 1
   * f(n) = f(n-2) + f(n-1)
   * 
   * 0 1 1 2 3 5 8 13 21 
   */

  /**
   * (abc) -> {abc, acb, bac, bca, cab, cba}
   * @param s
   * @return
   */

  public static List<String> permutations(String s) {
    List<String> result = new ArrayList<>();
    if (s.length() == 1) {
      result.add(s);
      return result;
    }

    for (int i = 0; i < s.length(); i++) {
      List<String> list = permutations(extractString(s, i));
      for (String ss : list) {
        result.add("" + s.charAt(i) + ss);
      }
    }

    return result;
  }

  public static String extractString(String s, int pos) {
    return s.substring(0, pos) + s.substring(pos + 1);

  }

  public static void main(String[] args) {
    System.out.println(permutations("ABC"));
  }
}
