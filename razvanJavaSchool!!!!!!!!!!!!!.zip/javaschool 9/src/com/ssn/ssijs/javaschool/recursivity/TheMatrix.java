/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TheMatrix {

  public static void main(String[] args) {
    int[][] matrix = { //
      { 0, 1, 1, 1, 1, 1, 1, 1 }, //
      { 0, 0, 0, 0, 0, 1, 1, 1 }, //
      { 1, 0, 1, 1, 0, 0, 0, 1 }, //
      { 1, 0, 1, 0, 0, 1, 0, 0 }, //
      { 1, 0, 0, 0, 1, 1, 1, 0 }, //
      { 1, 1, 1, 0, 0, 0, 1, 0 }, //
      { 1, 1, 1, 1, 1, 0, 0, 0 }, //
      { 1, 1, 1, 1, 1, 1, 1, 0 }, //
    };

    List<Point> solution = new ArrayList<Point>();
    Point start = new Point(0, 0);
    Point stop = new Point(7, 7);
    showMatrix(matrix);
    search(matrix, start, stop, solution);
  }

  private static void search(int[][] matrix, Point current, Point stop, List<Point> solution) {
    // daca am ajuns la margini
    if (current.x < 0 || current.y < 0 || current.x >= matrix.length || current.y >= matrix[0].length) {
      return;
    }

    // daca am lovit un perete
    if (matrix[current.x][current.y] == 1) {
      return;
    }

    // evitam buclele
    if (solution.contains(current)) {
      return;
    }

    // adaugam punctul curent la drumul curent
    solution.add(current);

    // daca am ajuns la solutie 
    if (current.equals(stop)) {
      // am ajuns la solutie
      System.out.println(solution);
      showSolutionOnMatrix(matrix, solution);
    } else { // daca nu am ajuns la solutie incercam sa mergem la vecini
      search(matrix, new Point(current.x + 1, current.y), stop, solution);
      search(matrix, new Point(current.x - 1, current.y), stop, solution);
      search(matrix, new Point(current.x, current.y + 1), stop, solution);
      search(matrix, new Point(current.x, current.y - 1), stop, solution);
    }

    // foarte important stergem punctul adaugat cu add
    solution.remove(solution.size() - 1);
  }

  private static void showSolutionOnMatrix(int[][] matrix, List<Point> solution) {
    for (int i = 0; i < matrix.length; i++) {
      for (int j = 0; j < matrix[i].length; j++) {
        System.out.print(solution.contains(new Point(i, j)) ? 2 : matrix[i][j]);
      }
      System.out.println();
    }
  }

  private static void showMatrix(int[][] matrix) {
    for (int[] row : matrix) {
      System.out.println(Arrays.toString(row));
    }
  }
}
