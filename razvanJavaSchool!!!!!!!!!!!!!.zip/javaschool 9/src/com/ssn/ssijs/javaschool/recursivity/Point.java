/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Point extends java.awt.Point {

  public Point(int i, int j) {
    super(i, j);
  }

  @Override
  public String toString() {
    return "(" + x + "," + y + ")";
  }
}
