/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SimpleTest {

  @Test
  public void test() {
    assertEquals("bc", Simple.extractString("abc", 0));
    assertEquals("ac", Simple.extractString("abc", 1));
    assertEquals("ab", Simple.extractString("abc", 2));
  }

}
