/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Min {
  public static void main(String[] args) {
    int min = minRec(new int[] { 5, 7, 3, 9, 4, 1, 9 });
    System.out.println(min);
  }

  private static int minRec(int[] arr) {
    if (arr.length == 1) {
      return arr[0];
    }

    return Math.min(//
      arr[0], //
      minRec(Arrays.copyOfRange(arr, 1, arr.length)));
  }
}
