/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.recursivity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Combinations {

  // comb(abc, 2) -> a + comb(bc, 1)
  //              -> b + comb(c, 1)
  //              -> c + comb("", 1)

  // arr(abc, 2) -> a + comb(bc, 1)
  //              -> b + comb(ac, 1)
  //              -> c + comb(ab, 1)

  // abc -> ab, ba, ac, ca, bc, cb

  public static List<String> getCombinations(String s, int k) {
    List<String> result = new ArrayList<>();
    if (k == 1) {
      for (char ch : s.toCharArray()) {
        result.add("" + ch);
      }
    }

    for (int i = 0; i < s.length(); i++) {
      char ch = s.charAt(i);
      List<String> list = getCombinations(s.substring(i + 1), k - 1);
      for (String s2 : list) {
        result.add(ch + s2);
      }
    }
    return result;
  }

  public static void main(String[] args) {
    System.out.println(getCombinations("ab", 2));
    System.out.println(getCombinations("abc", 1));
    System.out.println(getCombinations("abc", 2));
  }
}
