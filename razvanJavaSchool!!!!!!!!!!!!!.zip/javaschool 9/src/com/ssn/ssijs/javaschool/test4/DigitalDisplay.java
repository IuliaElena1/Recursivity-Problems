/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.test4;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DigitalDisplay {

  public void show(String text) {
    for (int slice = 0; slice < Digit.DIGIT_0.getData().length; slice++) {
      for (int col = 0; col < text.length(); col++) {
        char ch = text.charAt(col);
        Digit digit = Digit.getDigitByChar(ch);
        System.out.print(digit.getSlice(slice));
      }
      System.out.println();
    }
  }

}
