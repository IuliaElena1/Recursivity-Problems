/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.test4;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public enum Digit {
    DIGIT_0('0', //
      new String[] { //
        " ___ ", //
        "|   |", //
        "|   |", //
        "|   |", //
        "|___|" }), //
    DIGIT_1('1', //
      new String[] { //
        "     ", //
        "    |", //
        "    |", //
        "    |", //
        "    |" }), //
    DIGIT_2('2', //
      new String[] { //
        " ___ ", //
        "    |", //
        " ___|", //
        "|    ", //
        "|___ " }), //
    DIGIT_3('3', //
      new String[] { //
        " ___ ", //
        "    |", //
        " ___|", //
        "    |", //
        " ___|" }), //
    DIGIT_4('4', //
      new String[] { //
        "     ", //
        "|    ", //
        "|___ ", //
        "    |", //
        "    |" }), //
    DIGIT_5('5', //
      new String[] { //
        " ___ ", //
        "|    ", //
        "|___ ", //
        "    |", //
        " ___|" }), //
    DIGIT_6('6', //
      new String[] { //
        " ___ ", //
        "|    ", //
        "|___ ", //
        "|   |", //
        "|___|" }), //
    DIGIT_7('7', //
      new String[] { //
        " ___ ", //
        "    |", //
        "    |", //
        "    |", //
        "    |" }), //
    DIGIT_8('8', //
      new String[] { //
        " ___ ", //
        "|   |", //
        "|___|", //
        "|   |", //
        "|___|" }), //
    DIGIT_9('9', // 
      new String[] { //
        " ___ ", //
        "|   |", //
        "|___|", //
        "    |", //
        " ___|" }), //
    A('A', // 
      new String[] { //
        " ___ ", //
        "|   |", //
        "|___|", //
        "|   |", //
        "|   |" }), //
    M('M', // 
      new String[] { //
        "     ", //
        "|\\ /|", //
        "|   |", //
        "|   |", //
        "|   |" }), //
    DIGIT_DOUAPUNCTE(':', // 
      new String[] { //
        "   ", //
        "   ", //
        " o ", //
        "   ", //
        " o " }), //
    DIGIT_PUNCT('.', // 
      new String[] { //
        "   ", //
        "   ", //
        "   ", //
        "   ", //
        " o " }),//  
  ;

  private String[] data;
  private char ch;

  Digit(char ch, String[] data) {
    this.ch = ch;
    this.data = data;
  }

  public String[] getData() {
    return data;
  }

  public String getSlice(int row) {
    return data[row];
  }

  public static Digit getDigitByChar(char ch) {
    for (Digit digit : Digit.values()) {
      if (ch == digit.getChar()) {
        return digit;
      }
    }
    return null;
  }

  private char getChar() {
    return ch;
  }
}
