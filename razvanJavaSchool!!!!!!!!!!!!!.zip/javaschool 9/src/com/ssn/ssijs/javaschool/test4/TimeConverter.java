/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.test4;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class TimeConverter {

  public String convert(long time) {
    long secondsOfDay = (time / 1000) % (60 * 60 * 24);
    long sec = secondsOfDay % 60;
    long min = secondsOfDay / 60 % 60;
    long hou = secondsOfDay / (60 * 60) % (60 * 60);
    return padWithZeroes(hou) + ":" + //
      padWithZeroes(min) + ":" + //
      padWithZeroes(sec);// + "." + (time / 100 % 10) + "AM";
  }

  private String padWithZeroes(long nr) {
    return nr > 9 ? "" + nr : "0" + nr;
  }

}
