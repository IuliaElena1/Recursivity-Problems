/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.test4;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class DigitsClient {
  public static void main(String[] args) {
    DigitalDisplay d = new DigitalDisplay();
    d.show("1234213412342324");
  }
}
