/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.test4;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ClockClient {
  public static void main(String[] args) {
    TimeConverter timeConverter = new TimeConverter();
    DigitalDisplay display = new DigitalDisplay();

    long start = System.currentTimeMillis();
    while (true) {
      String time = timeConverter.convert(System.currentTimeMillis() - start);

      //System.out.println(time);
      display.show(time);
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        //
      }
    }
  }
}
