/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.classes;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class PersonClient {

  public static void main(String[] args) {

    Person p1 = new Person("231546123547", "Ghita", 30, 70);
    System.out.println(p1.toString());

    p1.setName("");
    p1.setCNP("");
    p1.setName("").setCNP("");

    Person p2 = new Person("231546123548", "Ion", 40, 80);
    System.out.println(p2.toString());
    Person p3 = new Person("231546123548", "Ion", 40);
    System.out.println(p3.toString());

    p1 = p2;
    p1.setAge(10);
    System.out.println("------------");
    System.out.println(p1.toString());
    System.out.println(p2.toString());

    p2.setAge(490);
    p3.setAge(690);

    p1.eat();
    p1.eat("cartofi");

    //    p1.age = 290;
    //    p2.age = 490;
    //    p3.age = 590;

    System.out.println(p1.toString());
    System.out.println(p2.toString());

    // p.age = 7;
    // p.method();

    // new Person("231546123547", "Ghita", 30, 70);
    m();
    m("asd");
    m("asd", "zxc");
    m("asd", "qwe", "zxc");

    int x = 10;
    myMethod(x);
    System.out.println(x);

    Person p = new Person("231546123547", "Ghita", 30, 70);
    myMethod(p);
    System.out.println(p);
  }

  private static void myMethod(Person p) {
    //p = new Person("231546123547", "Ghita", 40, 70);
    p.age = 40;
    //    p.setAge(40);
  }

  private static void myMethod(int x) {
    x = 5;
  }

  public static void m(String... args) {
    System.out.println(Arrays.toString(args));
  }

}
