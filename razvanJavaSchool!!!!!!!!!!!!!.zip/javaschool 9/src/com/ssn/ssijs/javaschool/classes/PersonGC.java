/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.classes;

import java.util.ArrayList;
import java.util.List;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class PersonGC {
  private static final long NR_PERSOANE = 100000;

  public static void main(String[] args) throws InterruptedException {
    List<Person> list = new ArrayList<Person>();
    String s = "";
    for (long i = 0; i < NR_PERSOANE; i++) {
      s += i;
      list.add(new Person("" + s, "" + s, 10, 10));
    }
  }
}
