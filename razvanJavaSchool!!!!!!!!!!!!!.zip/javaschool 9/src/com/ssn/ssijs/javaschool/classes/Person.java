/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.classes;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Person {
  public static int staticField = 0;

  private String cnp;
  private String name;
  public int age;
  private int weight;

  public Person(String cnp, String name, int age, int weight) {
    super();
    if (cnp.length() == 13) {
      this.cnp = cnp;
    } else {
      this.cnp = "CNP INCORECT";
    }
    this.name = name;
    this.age = age;
    this.weight = weight;
  }

  public Person(String cnp, String name, int age) {
    this(cnp, name, age, -1);
    System.out.println();
    System.out.println(staticField);
  }

  @Deprecated
  public void eat() {
    System.out.println(name + " eats.");
  }

  public void eat(String food) {
    System.out.println(name + " eats " + food);
  }

  @Override
  public String toString() {
    return cnp + " " + name + " " + age + " " + weight + " kg.";
  }

  public int getAge() {
    return age;
  }

  public String getString() {
    return null;
  }

  public void setAge(int age) {
    if (age < 200) {
      this.age = age;
    } else {
      System.out.println("Varsta invalida");
    }
  }

  @Override
  protected void finalize() throws Throwable {
    System.out.println("Obiectul " + name + " a fost sters din memorie");
  }

  public Person setName(String string) {
    return this;
  }

  public Person setCNP(String string) {
    return this;
  }

  public static void staticMethod() {
    System.out.println(staticField);
  }
}
