/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.classes;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class StaticPerson {
  public static final int STATIC_FIELD = 1;
  public int field;

  static {
    System.out.println("Cod static 1");
  }

  /**
   * 
   */

  {
    System.out.println("Cod nestatic 1");
  }

  public StaticPerson() {
    System.out.println("Constructor");
  }

  {
    System.out.println("Cod nestatic 2");
  }

  public static void main(String[] args) {
    System.out.println(STATIC_FIELD);
    StaticPerson sp = new StaticPerson();
    StaticPerson sp2 = new StaticPerson();
    StaticPerson sp3 = new StaticPerson();
    StaticPerson sp4 = new StaticPerson();
    System.out.println(sp.field);

    sp.run();
  }

  private void run() {

  }

  static {
    System.out.println("Cod static 2");
  }

}
