/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class WhileThing {
  public static void main(String[] args) {
    int i = 1;

    do {
      System.out.println(i);
      i++;
    } while (i < 11);

    i = 1;
    while (i < 11) {
      if (i % 2 == 0) {
        System.out.println(i);
      }
      i++;
    }

    i = 0;
    while (i < 10) {
      i++;
      //      if (i % 2 == 1) {
      //        continue;
      //      }

      System.out.print(i % 2 == 0 ? i + "\n" : "");
    }

    i = 0;
    while (true) {
      i++;
      System.out.println(i);
      if (i == 5) {
        break;
      }
    }

  }
}
