/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.exceptions;

import java.io.IOException;
import java.util.Scanner;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ExceptionsThing2 {
  static String readFirstLineFromFile(String path) throws IOException {
    try (Scanner scanner = new Scanner(System.in)) {
      scanner.nextLine();
    }
    return null;
  }

  public static void main(String[] args) {

    int result;

    try {

      result = next(new int[] { 1, 2, 3, 4, 5, 6 }, 6);
      System.out.println(result);
    } catch (LastElementException e1) {
      System.out.println("handling 1: " + e1.getMessage());
    } catch (NotFoundException e1) {
      System.out.println("handling 2: " + e1.getMessage());
    } finally {
      System.out.println("Finally");
    }

    try {
      result = next(new int[] { 1, 2, 3, 4, 5, 6 }, 6);
      System.out.println(result);
    } catch (LastElementException | NotFoundException e) {
      System.out.println(e.getMessage());
    }

    try {
      result = next(new int[] { 1, 2, 3, 4, 5, 6 }, 7);
      System.out.println(result);
    } catch (Exception e) {
      System.out.println("asdfasd" + e.getMessage());
    }

  }

  private static int next(int[] arr, int n) throws LastElementException, NotFoundException {
    for (int i = 0; i < arr.length; i++) {
      if (n == arr[i]) {
        if (i == arr.length - 1) {
          throw new LastElementException(n);
        } else {
          return arr[i + 1];
        }
      }
    }
    throw new NotFoundException(n);
  }
}
