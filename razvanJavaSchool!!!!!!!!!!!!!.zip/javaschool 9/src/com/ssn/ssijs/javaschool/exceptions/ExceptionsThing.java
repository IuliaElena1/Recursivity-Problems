/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.exceptions;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ExceptionsThing {
  public static int errorCode;

  public static void main(String[] args) {
    int result = next(new int[] { 1, 2, 3, 4, 5, 6 }, 3);
    if (errorCode >= 0) {
      System.out.println(result);
    } else if (errorCode == -1) {
      System.out.println("Eroare 1");
    } else if (errorCode == -2) {
      System.out.println("Eroare 2");
    }

    result = next(new int[] { 1, 2, 3, 4, 5, -1 }, -1);
    if (errorCode >= 0) {
      System.out.println(result);
    } else if (errorCode == -1) {
      System.out.println("Eroare 1");
    } else if (errorCode == -2) {
      System.out.println("Eroare 2");
    }

    result = next(new int[] { 1, 2, 3, 4, 5, 6 }, 7);
    if (errorCode >= 0) {
      System.out.println(result);
    } else if (errorCode == -1) {
      System.out.println("Eroare 1");
    } else if (errorCode == -2) {
      System.out.println("Eroare 2");
    }
  }

  private static int next(int[] arr, int n) {
    errorCode = 0;
    for (int i = 0; i < arr.length; i++) {
      if (n == arr[i]) {
        if (i == arr.length - 1) {
          errorCode = 1;
          return -1; // nerelevant
        } else {
          return arr[i + 1];
        }
      }
    }
    errorCode = 2;
    return -2; // nerelevant
  }
}
