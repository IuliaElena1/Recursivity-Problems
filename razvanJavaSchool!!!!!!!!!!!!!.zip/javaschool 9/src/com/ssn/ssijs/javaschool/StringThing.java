/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class StringThing {
  public static void main(String[] args) {
    String s = "abc";
    s = s + "d";
    System.out.println(s.charAt(1));
    System.out.println(s.substring(2));
    System.out.println(s.substring(1, 2));
    System.out.println(s.compareTo("bcd"));
    System.out.println(s.compareTo("aaa"));
    System.out.println(s.compareTo("abcd"));
    System.out.println(s.compareToIgnoreCase("ABCD"));
    System.out.println(s.equalsIgnoreCase("ABCD"));
    System.out.println(s.contains("bc"));
    System.out.println(s.endsWith("d"));
    System.out.println(s.startsWith("abc"));
    System.out.println(s.indexOf('c'));
    System.out.println(s.indexOf('q'));
    System.out.println(s.indexOf("abc"));
    System.out.println("abcabc".indexOf('c'));
    System.out.println("abcabc".indexOf('c', 3));
    System.out.println("abcabc".toCharArray());
    System.out.println("".isEmpty());
    System.out.println("      abc   ".trim());
    System.out.println("abcabc".lastIndexOf('c'));
    System.out.println("abcabc".toUpperCase());
    System.out.println("abcabcabc".replace("ab", "AB"));
    String[] splits = "qwe,asd;zxc\\cvb-dfgdfg".split("[,;:\\\\\\-]");
    System.out.println(Arrays.toString(splits));

    // STRINGUL E IMUTABIL !!!
    s = "abcd";
    s = s.replace('a', 'b');
    System.out.println(s);

    StringBuilder sb = new StringBuilder();
    sb.append("qwert");
    sb.append("sdafsdf");
    sb.toString();

    StringBuilder q2 = new StringBuilder();
    long start = System.currentTimeMillis();
    for (int i = 0; i < 100000; i++) {
      q2.append(i);
    }
    long stop = System.currentTimeMillis();
    System.out.println(stop - start);

    String q = "";
    start = System.currentTimeMillis();
    for (int i = 0; i < 100000; i++) {
      q += i;
    }
    stop = System.currentTimeMillis();
    System.out.println(stop - start);
  }

}
