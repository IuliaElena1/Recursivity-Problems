/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public abstract class Shape {
  private String color;

  public Shape(String color) {
    this.color = color;
  }

  public void showColor() {
    System.out.println("" + getClass().getName() + " -> " + color);
  }

  public abstract int getArea();

  @Override
  public String toString() {
    return super.toString();
  }

}
