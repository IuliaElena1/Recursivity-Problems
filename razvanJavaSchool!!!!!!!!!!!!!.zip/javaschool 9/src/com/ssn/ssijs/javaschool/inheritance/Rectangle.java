/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Rectangle extends Shape {
  private int width;
  private int length;

  public Rectangle(String color, int width, int length) {
    super(color);
    this.width = width;
    this.length = length;
  }

  @Override
  public int getArea() {
    return length * width;
  }

  @Override
  public void showColor() {
    System.out.println("Rectangle special thing");
    super.showColor();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + length;
    result = prime * result + width;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Rectangle other = (Rectangle) obj;
    if (this.getArea() != other.getArea())
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "Rectangle [width=" + width + ", length=" + length + "]";
  }

  public void m(String s) {
    System.out.println(1);
  }

  public void m(Object o) {
    System.out.println(2);
  }

}
