/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Sim {

  public static void main(String[] args) {
    boolean[] army1 = new boolean[1000];
    boolean[] army2 = new boolean[10000];
    Arrays.fill(army1, true);
    Arrays.fill(army2, true);

    while (true) {
      double total = getStatus(army1) + getStatus(army2);
      double p1 = getStatus(army1) / total;
      double p2 = getStatus(army2) / total;

      fight(army1, p1);
      fight(army2, p2);

      System.out.println(getStatus(army1) + " " + getStatus(army2));

      if (isAllDead(army1) || isAllDead(army2)) {
        break;
      }
    }
  }

  private static int getStatus(boolean[] arr) {
    int counter = 0;
    for (boolean b : arr) {
      if (b) {
        counter++;
      }
    }
    return counter;
  }

  /**
   *   |      |                |
   *   0      0.33             1
   */
  private static void fight(boolean[] army, double probability) {
    for (int i = 0; i < army.length; i++) {
      if (Math.random() > probability) {
        army[i] = false;
      }
    }
  }

  public static boolean isAllDead(boolean[] arr) {
    for (boolean b : arr) {
      if (b) {
        return false;
      }
    }
    return true;
  }
}
