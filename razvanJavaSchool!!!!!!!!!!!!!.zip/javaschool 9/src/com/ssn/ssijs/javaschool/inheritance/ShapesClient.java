/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ShapesClient {
  public static void main(String[] args) {
    Shape[] shapes = { new Square("red", 10), new Square("blue", 5), //
      new Rectangle("red", 10, 5), new Rectangle("blue", 5, 15), //
      new Circle("yellow", 10) };

    for (Shape s : shapes) {
      s.showColor();
      System.out.println(s.getArea());
    }

    Shape shape = new Circle("red", 1);
    //Shape shape = new Square("red", 1);
    ((Circle) shape).getDiameter();

    if (shape instanceof Circle) {
      ((Circle) shape).getDiameter();
    }

    if (shape instanceof Rectangle) {
      ((Rectangle) shape).getArea();
    } else {
      System.out.println("shape nu e un rectangle");
    }

    //    Square[] squares = { new Square("red", 10), new Square("blue", 5) };
    //    for (Square sq : squares) {
    //      sq.showColor();
    //      System.out.println(sq.getArea());
    //    }
    //
    //    Rectangle[] rectangles = { new Rectangle("red", 10, 5), new Rectangle("blue", 5, 15) };
    //    for (Rectangle re : rectangles) {
    //      re.showColor();
    //      System.out.println(re.getArea());
    //    }

  }
}
