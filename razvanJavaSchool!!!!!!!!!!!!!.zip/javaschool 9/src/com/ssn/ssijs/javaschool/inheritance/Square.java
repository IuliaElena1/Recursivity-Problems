/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Square extends Shape {
  int side;

  public Square(String color, int side) {
    super(color);
    this.side = side;
  }

  @Override
  public int getArea() {
    return side * side;
  }
}
