/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.inheritance;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class Circle extends Shape {
  public int radius;

  public Circle(String color, int radius) {
    super(color);
    this.radius = radius;
  }

  @Override
  public int getArea() {
    return (int) (Math.PI * radius * radius);
  }

  public int getDiameter() {
    return (int) (2 * Math.PI * radius);
  }
}
