/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class IfThing {
  public static void main(String[] args) {
    int nota = 10;

    if (nota > 8) {
      System.out.println("Foarte bine");
    } else if (nota > 6) {
      System.out.println("Acceptabil");
    } else {
      System.out.println("Respins");
    }

    int x = 1;
    if (x == 3) {

    }

    boolean b = false;
    if (b == true) {
      System.out.println("Intra");
      System.out.println(b);
    }
  }
}
