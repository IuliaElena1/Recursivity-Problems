/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SerializationThing {
  static String s = "abc";

  public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
    // save();
    load();
  }

  private static void load() throws FileNotFoundException, IOException, ClassNotFoundException {
    ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("database.ser")));
    String s2 = (String) ois.readObject();
    ois.close();
    System.out.println(s2);
  }

  private static void save() throws FileNotFoundException, IOException {
    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("database.ser")));
    oos.writeObject(s);
    oos.close();
  }

}
