/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.serialization;

import java.io.Serializable;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class User implements Serializable {
  private static final long serialVersionUID = 1L;
  private String name;
  private String password;
  private int age;

  /**
   * @param name
   * @param password
   */
  public User(String name, String password) {
    super();
    this.name = name;
    this.password = password;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  @Override
  public String toString() {
    return "User [name=" + name + ", password=" + password + age + "]";
  }

}
