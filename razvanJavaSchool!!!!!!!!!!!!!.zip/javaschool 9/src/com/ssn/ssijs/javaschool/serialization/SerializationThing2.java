/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class SerializationThing2 {
  private Database db = new Database();

  public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
    SerializationThing2 st = new SerializationThing2();
    st.doJob();
  }

  private void doJob() throws FileNotFoundException, IOException, ClassNotFoundException {
    /*  db.addUser(new User("qwe", "qwe"));
    db.addUser(new User("asd", "asd"));
    db.addUser(new User("zxc", "zxc"));
    save();*/
    db = load();
    System.out.println(db.toString());
  }

  private Database load() throws FileNotFoundException, IOException, ClassNotFoundException {
    ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("database.ser")));
    Database database = (Database) ois.readObject();
    ois.close();
    return database;
  }

  private void save() throws FileNotFoundException, IOException {
    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("database.ser")));
    oos.writeObject(db);
    oos.close();
  }

}
