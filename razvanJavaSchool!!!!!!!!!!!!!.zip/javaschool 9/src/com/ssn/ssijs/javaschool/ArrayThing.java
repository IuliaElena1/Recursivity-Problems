/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssn.ssijs.javaschool;

import java.util.Arrays;

/**
 * @author <a href="mailto:rveina@ssi-schaefer-noell.com">rveina</a>
 * @version $Revision: $, $Date: $, $Author: $
 */

public class ArrayThing {
  public static void main(String[] args) {
    int[] arr = new int[5];

    System.out.println(arr.length);
    arr[2] = 5;
    System.out.println(Arrays.toString(arr));
    System.out.println(arr[2]);

    int[] arr2 = { 1, 2, 3, 4, arr[2] };
    System.out.println(Arrays.toString(arr2));

    System.out.println(arr[4]);

    int[][] matrix = { //
      { 1, 2, 3 }, // 
      { 4, 5, 6 }, //
      { 4, 5, 6, 7 }, //
      { 7, 8, 9, 9, 9 } //
    };

    System.out.println(matrix[0][0]);
    System.out.println(matrix[0][2]);
    System.out.println(matrix[2][0]);
    System.out.println(matrix[2][2]);

    System.out.println(matrix[0].length);

    for (int[] element : matrix) {
      System.out.println(Arrays.toString(element));
    }

    //System.arraycopy(arg0, arg1, arg2, arg3, arg4);

    // Arrays.

  }

  public int test(int[] x) {
    if (x == null) {
      return -1;
    }
    return 0;
  }
}
