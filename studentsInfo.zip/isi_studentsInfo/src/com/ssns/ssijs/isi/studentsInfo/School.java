/*
 * Copyright (c) 2019 SSI Schaefer Noell GmbH
 *
 * $Header: $
 */

package com.ssns.ssijs.isi.studentsInfo;

public enum School {
    UVT, UPT, UNDEFINED;

}
